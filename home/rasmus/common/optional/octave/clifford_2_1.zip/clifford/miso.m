function m = miso(M)
% MISO Convert real/complex (block) array to multivector array.
% This function is the converse of ISOM (q.v.) with one exception. MISO
% accepts a column vector as input, and will return a multivector array,
% whereas ISOM returns a matrix (with the multivector coefficients in
% lexical order down the first column).

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global clifford_descriptor %#ok<GVMIS> 

narginchk(1, 1), nargoutchk(0, 1)

if ~isnumeric(M)
    error(['Parameter must be numeric, given: ', class(M)])
end

if ~ismatrix(M)
    error('Input array must be two-dimensional.')
end

if ndims(M) > 2 %#ok<ISMAT> 
    error('Cannot handle arrays with more than two dimensions')
end

[r, c] = size(M);

m = cast(clifford_descriptor.m, 'double');

if r/m ~= fix(r/m)
    error(['Number of rows in input is inconsistent with an ', ...
           'isomorphic representation in the current algebra. ', ...
           'Require a multiple of ', num2str(m), '. Found: ', ...
           num2str(r), '.'])
end

if c/m ~= fix(c/m) && c ~= 1 % We do accept a single column.
    error(['Number of columns in input is inconsistent with an ', ...
           'isomorphic representation in the current algebra. ', ...
           'Require a multiple of ', num2str(m), '. Found: ', ...
           num2str(c), '.'])
end

% Because mat_to_clpqr is a (private) class method, we must pass it a
% multivector argument, so we put the real/complex array M into a
% multivector as the scalar part.

m = cfeval('mat_to_clpqr', clifford(M));

end

% $Id: miso.m 369 2022-12-21 14:50:03Z sangwine $