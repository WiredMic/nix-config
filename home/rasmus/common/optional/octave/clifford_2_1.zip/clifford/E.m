function result = E
% E Vector representing bivector wedge(eo, ei) (conformal multivectors)

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(0,0), nargoutchk(0,1)

global conformal_descriptor %#ok<*GVMIS> 
        
if isempty(conformal_descriptor)
    error('No conformal algebra has been initialised.')
end

s = clifford_signature;

p = s(1);
q = s(2);

% The result we need is epq, the bivector with indices p and q. The method
% below is not the only way this could be done, but it is one of the
% easiest.

% TODO Consider a persistent variable to avoid the computation on second
% and subsequent calls.

result = conformal(clifford(['e', num2str(p), num2str(p + q)]));

end

% $Id: E.m 355 2022-10-20 16:16:56Z sangwine $

