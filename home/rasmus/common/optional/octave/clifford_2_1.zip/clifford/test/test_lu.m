function test_lu
% Test code for the clifford LU decomposition.

% Copyright (c) 2015, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global clifford_descriptor

s = clifford_signature;
if s(3) ~= 0
    tdisp(['Skipping test of LU decomposition: ', ...
           'multivector inverse is not defined in this algebra'])
else
    tdisp('Testing LU decomposition ...');

    M = cast(clifford_descriptor.m, 'double');

    if M > 1024
        %A = randm(4, 4, 'partial', 5/M); %, 'sparse', max(5/16, 5/M));
                A = randm(4, 4, 'sparse', max(5/16, 5/M));
    else
        A = randm(5, 'partial', min(1, 5/M));
    end
    
    [L, U, P] = lu(A);

    T = 2e-5;
    
    if max(max(abs(L * U - P * A))) < T
        tdisp('Passed')
    else
        twarning(['LU decomposition residual: ', ...
                  num2str(max(max(abs(L * U - P * A)))), ...
                  ' exceeds test threshold: ', num2str(T) ])
    end

end

end

% $Id: test_lu.m 383 2023-08-21 16:53:13Z sangwine $
