function test_contractions
% Test code for the clifford left and right contraction functions. This
% also provides a test for the Dorst inner product (DIP), using formula
% (2.11) in:
%
% Leo Dorst, 'The inner products of geometric algebra', ch. 2, pp. 35-46,
% in: L. Dorst, C. Doran, J. Lasenby, 'Applications of geometric algebra in
% computer science and engineering', Birkhauser, Boston, 2002.
% DOI: 10.1007/978-1-4612-0089-5.

% Copyright © 2015, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing left and right contractions ...');

global clifford_descriptor

% TODO Add tests on array arguments.

% The tests below cannot all be used for all algebras, so we return early
% and skip any tests that cannot be executed in the current algebra because
% the necessary basis elements don't exist.

if clifford_descriptor.n < 2
    tdisp('Not testing left and right contractions, algebra too small.')
    return
end

cz = 0 .* e0; % A multivector zero.

% The parameters are left, right arguments, result from a left contraction,
% test number.

contraction(e0, e0, e0,       1);
contraction(e0, e0, e0,       2);
contraction(e1, e1, e1 .* e1, 3);

if clifford_descriptor.n < 3, tdisp('Passed'); return, end

contraction(e12, e12, e12 .* e12,  4);
contraction(e12, e1, cz,           5);
contraction(e12, e2, cz,           6);
contraction(e1, e12, e1 .* e1 .* e2, 7);

if clifford_descriptor.n < 4, tdisp('Passed'); return, end

contraction(e12, e123, -e3 .* e1 .* e1 .* e2 .* e2, 8);
contraction(e123, e12, cz,                          9);

if clifford_descriptor.n < 5, tdisp('Passed'); return, end

contraction(e123, e1234, -e4 .* e1 .* e1 .* e2 .* e2 .* e3 .* e3, 10);
contraction(e4, e1234, -e123 .* e4 .* e4,                         11);

% Now use the formula (2.11) given by Dorst (attributed to L. Svensson) to
% test the Dorst inner product, the contractions, and the scalar product):

a = randm; b = randm;

compare(left_contraction(a, b) + right_contraction(a, b), ...
        scalar_product(a, b)   + dip(a, b), ...
        1e-10, 'Contractions and Dorst inner product fail Svensson test.');

tdisp('Passed');

end

function contraction(l, r, y, n)
% Applies tests to the left and right contraction.

check(left_contraction(l, r) == y, ...
    ['Left contraction fails test ' num2str(n)]);
check(right_contraction(reverse(r), reverse(l)) == reverse(y), ...
    ['Right contraction fails test ' num2str(n)]);

end

% $Id: test_contractions.m 349 2022-10-17 20:01:11Z sangwine $
