function compare(A, B, T, E)
% Test function to check that two multivector arrays (real or complex)
% are equal, to within a tolerance, and if not, to output an error or
% warning message from the string in the parameter E. If E starts with the
% character 'W' a warning is output and not an error. This makes it
% possible to run tests which sometimes fail, but should not be regarded as
% outright failures (because the code works on some inputs).

% Copyright (c) 2015, 2021 Stephen J. Sangwine and Eckhard Hizer
% See the file : Copyright.m for further details.

narginchk(4, 4), nargoutchk(0, 0)

if any(abs(abs(A - B)) > T, 'all')
    Diff = max(max(abs(abs(A - B))));
    Message = [' Tolerance error: ', num2str(Diff), ', tolerance: ', num2str(T)];
    if E(1) == 'W'
        twarning([E(2:end), Message]);
    else
        terror([E, Message]);
    end
end

end

% $Id: compare.m 386 2024-02-08 20:28:22Z sangwine $
