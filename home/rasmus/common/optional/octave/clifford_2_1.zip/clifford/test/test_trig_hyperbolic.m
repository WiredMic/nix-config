function test_trig_hyperbolic
% Test code for the Clifford trigonometric and hyperbolic functions. Since
% these use FUNMV, it also tests that function.

% Copyright © 2023 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing trigonometric and hyperbolic functions ...')

% Errors are greater in algebras with larger dimension, so we vary the
% tolerance according to the dimension of the algebra. The lowest value
% of n is 0 (for algebra Cl(0,0)) so we need to index the tolerance
% vector with one greater than n. The largest value of n supported by
% the toolbox is 16. So we need 17 tolerance values.

global clifford_descriptor %#ok<GVMIS>

if clifford_descriptor.signature(3) ~= 0
    tdisp(['Cannot test trigonometric and hyperbolic functions ', ...
           'in algebra with r > 0 due to limitation in FUNMV function.'])
    return
end

tolerance = logspace(-5, -3, 17);

T = tolerance(clifford_descriptor.n + 1);

% Test whether each function and its inverse are indeed inverses. Ordering
% matters here, just as with the numerical versions of these functions.
% This is because the functions are multivalued and return a value within a
% limited range. If the original value was outside that range, the inverse
% won't match the original value.

% TODO It might be better here not to use random coeficients, but randomly
% positioned coefficients with magnitude 1. E.g. e34 + e456. However, the
% result of a function will not be limited to the same coefficients (small
% values tend to occur in other coefficients) so inverting will still
% result in a larger number of non-zero coefficients, but some will be
% small.

if clifford_descriptor.n <= 10
    A = randm;
    B = randm;
    W = '';
else
    % For larger algebras use a multivector with a limited number of
    % elements, otherwise the calculations take too long. Here we use the
    % W (warn) flag on the error message, because tolerance errors are more
    % likely.
    W = 'W';
    F = 5/cast(clifford_descriptor.m, 'double');
    A = randm('partial', F);
    B = randm('partial', F);
end

compare(sin(asin(A)),   A, T, [W,  'Sin function fails inverse test 1.']);
compare(cos(acos(A)),   A, T, [W,  'Cos function fails inverse test 1.']);
compare(tan(atan(A)),   A, T, [W,  'Tan function fails inverse test 1.']);
compare(sinh(asinh(A)), A, T, [W, 'Sinh function fails inverse test 1.']);
compare(cosh(acosh(A)), A, T, [W, 'Cosh function fails inverse test 1.']);
compare(tanh(atanh(A)), A, T, [W, 'Tanh function fails inverse test 1.']);

% The complex tests are more likely to fail, so we use the 'W' prefix on
% the message to output a warning rather than an error.

Z = complex(A, B);

compare(sin(asin(Z)),   Z, T,  'WSin function fails inverse test 2.');
compare(cos(acos(Z)),   Z, T,  'WCos function fails inverse test 2.');
compare(tan(atan(Z)),   Z, T,  'WTan function fails inverse test 2.');
compare(sinh(asinh(Z)), Z, T, 'WSinh function fails inverse test 2.');
compare(cosh(acosh(Z)), Z, T, 'WCosh function fails inverse test 2.');
compare(tanh(atanh(Z)), Z, T, 'WTanh function fails inverse test 2.');

% Test using identities.

compare(sin(Z)./cos(Z),       tan(Z), T, 'WSin/cos is not equal to tan.');
compare(sinh(Z)./cosh(Z),    tanh(Z), T, 'WSinh/cosh is not equal to tanh.');
compare(sin(Z).^2 + cos(Z).^2,    e0, T, 'WSin^2 + cos^2 is not equal to e0.');
compare(sinh(Z).^2 - cosh(Z).^2, -e0, T, 'WSinh^2 - cosh^2 is not equal to -e0.');

% Test whether these functions work with arrays of multivectors. Since they
% all use FUNMV, testing one function should suffice.

if clifford_descriptor.n <= 10
    A = randm(2, 3);
else
    A = randm(2, 3, 'partial', 5/cast(clifford_descriptor.m, 'double'));
end
B = sin(A);

for row = 1:2
    for col = 1:3
        compare(sin(A(row, col)), B(row, col), T, ...
            'Sin function fails on 2D array.')
    end
end

C = sin(A(2, :));
D = sin(A(:, 2));

compare(B(2, :), C, T, 'Sin function fails on row test.');
compare(B(:, 2), D, T, 'Sin function fails on column test.');

tdisp('Passed')

% $Id: test_trig_hyperbolic.m 391 2024-02-08 21:03:35Z sangwine $
