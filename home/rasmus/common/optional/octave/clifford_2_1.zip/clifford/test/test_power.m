function test_power
% Test code for the power function.

% Copyright (c) 2015 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global clifford_descriptor %#ok<GVMIS> 

% Errors are greater in algebras with larger dimension, so we vary the
% tolerance according to the dimension of the algebra. The lowest value of
% n is 0 (for algebra Cl(0,0)) so we need to index the tolerance vector
% with one greater than n. The largest value of n supported by the toolbox
% is 16. So we need 17 tolerance values.

tolerance = logspace(-4, -2, 17);

T = tolerance(clifford_descriptor.n + 1);

tdisp('Testing power function ...');

% Test the inverse operation, if it is defined.

s = clifford_signature;
if s(3) ~= 0
    tdisp(['Not testing power function with exponent -1 because the ', ...
           'inverse is not defined in algebras with r > 0.'])
else
    
    m = randm(2, 1, 'partial', max(0.25, 1/cast(clifford_descriptor.m, 'double')));
    p = m.^-1; % Compute the inverse of each element in m.
    
    % Sometimes one element of the result will be out of tolerance, but the
    % other three are not. We let this pass, because it is due to numerical
    % conditions, and does not show the algorithm to be faulty.
    % TODO Establish why sometimes one value is out of tolerance - could we
    % deal with it better?
    
    D = abs(abs(m .* p - 1e0));
    L = D > T;
    N = sum(L(:));
    if N > 1
        % This is how we used to do the test. If more than one element is
        % outside tolerance, compare will raise an error and show the diff.
        compare(m .* p, 1e0, T, 'Multivector elementwise inverse fails.');
    elseif N > 0
        twarning(['One value out of four in multivector elementwise', ...
                  'inverse was out of tolerance']);
    end

end

% Test small integer powers from zero upwards. There are two cases (scalar
% MV to integer power or vector of integer powers; array MV to scalar
% integer power).

m = randm;

check(m.^0 == e0, 'Power fails with exponent of zero.');

for j=1:16
    compare(m.^j, prod(repmat(m, 1, j)), j .* 1e-9, ...
        ['Power fails for exponent ', num2str(j)]);
end

p = m.^[2,3,5,7,8];

compare(m.^2, p(1), T, 'Power fails on 1st integer in row exponent');
compare(m.^3, p(2), T, 'Power fails on 2nd integer in row exponent');
compare(m.^5, p(3), T, 'Power fails on 3rd integer in row exponent');
compare(m.^7, p(4), T, 'Power fails on 4th integer in row exponent');
compare(m.^8, p(5), T, 'Power fails on 5th integer in row exponent');

p = m.^[0;1;5;7;17];

compare(m.^0,  p(1), T, 'Power fails on 1st integer in column exponent');
compare(m.^1,  p(2), T, 'Power fails on 2nd integer in column exponent');
compare(m.^5,  p(3), T, 'Power fails on 3rd integer in column exponent');
compare(m.^7,  p(4), T, 'Power fails on 4th integer in column exponent');
compare(m.^17, p(5), T, 'Power fails on 5th integer in column exponent');

m = randm(2,3);

p = m.^3;

compare(p(1,3), m(1,3).^3, T, 'Power fails on array MV raised to power 3');
compare(p(2,2), m(2,2).^3, T, 'Power fails on array MV raised to power 3');

tdisp('Passed')

tdisp('Testing mpower function (^) ...')

m = randm(3, 3, 'partial', max(0.25, 1/cast(clifford_descriptor.m, 'double')));

if s(3) ~= 0
    tdisp(['Not testing mpower function with exponent -1 because the ', ...
           'inverse is not defined in algebras with r > 0.'])
else
    I = inv(m);
    compare(m^(-1), I,     T, 'clifford/mpower failed inverse test.')
    compare(m^(-2), I * I, T, 'clifford/mpower failed inverse square test.')
end

compare(m^0,    eye(size(m)),      T, 'clifford/mpower failed test with power 0.')

compare(m^1,    m,                 T, 'clifford/mpower failed test with power 1.')
compare(m^2,    m*m,               T, 'clifford/mpower failed square test.')
compare(m^3,    m*m*m,             T, 'clifford/mpower failed cube test.')
compare(m^4,    m*m*m*m,           T, 'clifford/mpower failed test with power 4.')
compare(m^5,    m*m*m*m*m,         T, 'clifford/mpower failed test with power 5.')
compare(m^6,    m*m*m*m*m*m,       T, 'clifford/mpower failed test with power 6.')
compare(m^7,    m*m*m*m*m*m*m,     T, 'clifford/mpower failed test with power 7.')
compare(m^8,    m*m*m*m*m*m*m*m,   T, 'clifford/mpower failed test with power 8.')
compare(m^9,    m*m*m*m*m*m*m*m*m, T, 'clifford/mpower failed test with power 9.')

% This test checks out the general case code in MPOWER using matrix
% logarithm and exponential. NB We don't compare with SQRTM because that
% seems to find a different root of the matrix. TODO Investigate further.

if s(3) ~= 0
    tdisp(['Not testing mpower function with fractional exponents because the ', ...
           'logm and expm functions are sometimes wildly inaccurate in algebras with r > 0.'])
else
    % The following tests require use of logs and exponentials and a
    % problem arises in the case of negative or imaginary eigenvalues.
    % Reference:
    % Paul Leopardi, 'Approximating functions in Clifford algebras: What to
    % do with negative eigenvalues', Australian Mathematical Society
    % Meeting, Adelaide, September 2009. [PDF presentation slides, slide
    % 18.] Available: https://maths-people.anu.edu.au/~leopardi/  ...
    %         AGACSE-2010-Leopardi-clifford-functions-long-talk.pdf
    %
    % We handle this by not running the test in the following list of
    % algebras, compiled from slide 20 of the above document. The value of
    % r is not listed because we have already excluded that above.

    % TODO If or when the problem of imaginary eigenvalues has been
    % resolved (see the sqrtm and logm functions for notes), the avoid list
    % here could be removed, and the tests could be run unconditionally.

    % Cl(0,1), CL(1, 4) and Cl(0,5) were added to this list, because errors
    % arise. Unsure why.

    Avoid = [0, 0; 0, 1;                   0, 5; 0, 6; 0, 7; ...
             1, 0; 1, 1;             1, 4;             1, 7; ...
             2, 0; 2, 1; 2, 2; ...
                   3, 1; 3, 2; 3, 3; ...
                         4, 2; 4, 3; 4, 4; ...
                               5, 3; 5, 4; 5, 5; ...
                                     6, 4; 6, 5; 6, 6; ...
                                           7, 5; 7, 6; 7, 7];
    if ismember(array2table(s(1:2), 'VariableNames', {'p', 'q'}), ...
                array2table(Avoid,  'VariableNames', {'p', 'q'}))

        tdisp(['Not testing mpower function with fractional exponents ', ...
               'in this algebra (see code).'])
               % Reason: high probability of imaginary eigenvalues which
               % will raise an error in the logm function.
    else
        % We construct a matrix here, rather than a random matrix, because
        % random matrices often result in errors.

        m = randm(3);
        m = m * m';

        compare((m^2)^0.5,   m, T, 'Wclifford/mpower failed test with power 1/2')
        compare((m^3)^(1/3), m, T, 'Wclifford/mpower failed test with power 1/3')
    end
end

tdisp('Passed')

end

% $Id: test_power.m 383 2023-08-21 16:53:13Z sangwine $
