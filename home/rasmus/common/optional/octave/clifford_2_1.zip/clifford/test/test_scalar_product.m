function test_scalar_product
% Test code for the clifford scalar product function.

% Copyright (c) 2015 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing scalar product ...');

global clifford_descriptor

M = cast(clifford_descriptor.m, 'double');

m1 = randm(2, 2, 'partial', min(1, 5/M)); % Make two random arrays.
m2 = randm(2, 2, 'partial', min(1, 7/M));

% The test is based on a simple formula for computing the scalar product.
% The scalar_product function does not use this formula because it would
% compute the entire product of two multivectors and then discard most of
% the result. We do however use the formula here as a check that the rather
% more complicated code in the scalar product function yields the correct
% result. This takes some time because of the time wasted computing the
% parts of the result that are discarded, which is significant in larger
% algebras.

check(scalar_product(m1, m2) == part(m1 .* m2, 1), 'Scalar product fails.');

tdisp('Passed');

end

% $Id: test_scalar_product.m 324 2022-04-11 20:22:59Z sangwine $
