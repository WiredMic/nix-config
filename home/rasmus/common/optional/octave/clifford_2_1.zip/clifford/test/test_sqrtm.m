function test_sqrtm
% Test code for the Clifford sqrtm function.

% Copyright (c) 2019 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

s = clifford_signature;

if s(3) > 0
    tdisp(['Skipping test of matrix square root: ', ...
           'cannot be computed in this algebra.']);
    return
end

tdisp('Testing matrix square root function ...')

global clifford_descriptor %#ok<GVMIS> 

M = cast(clifford_descriptor.m, 'double');
N = cast(clifford_descriptor.n, 'double');

T = 1e-10;

% This test is particularly time-consuming, especially for algebras with N
% greater than 10 or 11. Therefore we use a smaller test matrix for the
% larger values of N.

array_size = [5, 5, 5, 5, 4, 4, 4, 3, 3, 2, 2, 2, 2, 2, 2, 2];

D = array_size(N + 1); % N ranges from 0 to 15. Indices run from 1 to 16.

% Test 1. Real multivector data.

m = randm(D, 'partial', min(1, 5/M));

compare(m, sqrtm(m)^2, T, 'Wclifford/sqrtm failed test 1.');

% Test 2. Complex multivector data.

E = max(2, round(D/2)); % These values are roughly 1/2 of D, but the result
                        % must be integer, and no less than 2, otherwise we
                        % no longer have a matrix, just a single
                        % multivector.

m = complex(randm(E, 'partial', min(1, 5/M)), ...
            randm(E, 'partial', min(1, 5/M)));

compare(m, sqrtm(m)^2, T, 'Wclifford/sqrtm failed test 2.');

tdisp('Passed');

% $Id: test_sqrtm.m 386 2024-02-08 20:28:22Z sangwine $
