function test_expm
% Test code for the Clifford expm and logm functions.

% Copyright (c) 2019 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

m = randm(3);
c = complex(m, randm(3));

T = 1e-8;

global clifford_descriptor %#ok<GVMIS> 

s = clifford_descriptor.signature;

% These are very simple tests, based on a property of exponentials that
% applies only when the products commute. If we used two different matrices
% the formula would not hold (see Campbell-Baker-Haussdorf formula). That
% test is for another day ... TODO.

if s(3) > 0
    tdisp(['Skipping test of matrix exp function, cannot be computed', ...
           ' in this algebra because ISO function cannot handle r > 0.']);
else
    tdisp('Testing matrix exp function (expm) ...')

    compare(expm(m)^2, expm(2 .* m), T, 'clifford/expm failed test 1.');
    compare(expm(c)^2, expm(2 .* c), T, 'clifford/expm failed test 2.');

    tdisp('Passed')
end

% Testing the logarithm function is not so easy because of the occurrence
% of negative or imaginary eigenvalues.
%
% Reference:
% Paul Leopardi, 'Approximating functions in Clifford algebras: What to
% do with negative eigenvalues', Australian Mathematical Society
% Meeting, Adelaide, September 2009. [PDF presentation slides, slide
% 18.] Available: https://maths-people.anu.edu.au/~leopardi/  ...
%         AGACSE-2010-Leopardi-clifford-functions-long-talk.pdf
%
% We handle this by not running the test in the following list of
% algebras, compiled from slide 20 of the above document.

if s(3) > 0
    % This may not be true, if we use isom/miso.
    tdisp(['Skipping test of matrix logarithm: ', ...
           'cannot be computed in this algebra.']);
    return
end

% TODO If or when the problem of imaginary eigenvalues has been
% resolved (see the sqrtm and logm functions for notes), the avoid list
% here could be removed, and the tests could be run unconditionally.

Avoid = [0, 0;                               0, 6; 0, 7; ...
         1, 0; 1, 1;                               1, 7; ...
         2, 0; 2, 1; 2, 2; ...
               3, 1; 3, 2; 3, 3; ...
                     4, 2; 4, 3; 4, 4; ...
                           5, 3; 5, 4; 5, 5; ...
                                 6, 4; 6, 5; 6, 6; ...
                                       7, 5; 7, 6; 7, 7];

if ismember(array2table(s(1:2), 'VariableNames', {'p', 'q'}), ...
            array2table(Avoid,  'VariableNames', {'p', 'q'}))

    tdisp('Not testing logm function in this algebra (see code)')
    % The reason for not testing is a high probability of imaginary
    % eigenvalues which will raise an error in the logm function. See the
    % reference above.
    return
end

tdisp('Testing matrix log function (logm) ...')

% See the Wikipedia article: 'Logarithm of a matrix', section Properties,
% where several properties are given, for matrices with specific properties
% (positive definite for example). Since we don't know which if any of
% these properties apply to multivector matrices, we resort to finding a
% formula that seems to work, and using it. The purpose of the test after
% all is to check that the logm function works in a basic sense. We can't
% do more without mathematical knowledge about matrix logarithms of
% multivector matrices.

n = m * m';

compare(logm(inv(n)), complex_conjugate(-logm(n)), T, ...
    'Wclifford/logm failed test 1.');

tdisp('Passed')

% $Id: test_expm.m 383 2023-08-21 16:53:13Z sangwine $
