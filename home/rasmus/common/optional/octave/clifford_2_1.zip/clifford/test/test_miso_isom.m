function test_miso_isom
% Test code for the clifford isomorphism functions miso and isom including
% private functions that implement the isomorphism in each direction.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing miso/isom isomorphisms ...');

% The matrix isomorphisms are exact, since all they do is lay out a matrix
% with numerical values copied from the multivector and vice versa, and
% they work for all signatures, including those where r > 0.

% Test the multiplication of basis elements. An exhaustive test here would
% be too time consuming (hours) for large algebras, so we choose elements
% at random, testing only a small selection.

B = clifford_basis;
K = isom(B); % This will be a block column vector representing B.
c = size(K, 2); % c is the size of the (square) blocks.
L = length(B);

N = min(8, L); % The number of elements to test.

index_l = randi(L, 1, N); % These are indices into B, the multivector basis
index_r = randi(L, 1, N); % for the left and right operands of the product.

index = 1:c:c * L; % These are indices into the block column vector k.

for i = 1:N
    j = index_l(i);
    k = index_r(i);
    if any(isom(B(j) .* B(k)) - K(index(j):index(j)+c-1, :) ...
                              * K(index(k):index(k)+c-1, :), 'all')
           terror(['Multiplication of basis elements fails at index ', ...
                   num2str(j), ' times ', num2str(k)])
    end
end

% Test the isomorphisms from a given algebra Cl(p,q) to a matrix of real
% values. Because of the two different multiplication methods here, there
% can be a small difference in the results.

T = 1e-10;

A = randm('partial', N/L); B = randm('partial', N/L);

a = isom(A); b = isom(B); c = isom(A * B);

residual = max(max(abs(a * b - c)));
if residual > T
    terror(['Isomorphism to matrix fails with residual ', num2str(residual)])
end

% Now test that we can map the matrix of reals back to the algebra we
% started with. This should be exact.

E = miso(a);

if E ~= A
    terror(['Isomorphism from matrix back to multivector fails'])
end

% Now test that isom/miso work for various matrices and vectors of
% multivectors. These are exact tests, what we are checking here is that
% each isomorphism is exactly reversible.

A = randm(3, 1, 'partial', N/L); % Single column of multivectors.

check(all(miso(isom(A  )) == A  ), 'miso/isom fails for column of multivectors')
check(all(miso(isom(A.')) == A.'), 'miso/isom fails for row of multivectors')

A = randm(2, 3, 'partial', N/L);

check(all(miso(isom(A  )) == A  , 'all'), 'miso/isom fails on wide matrix')
check(all(miso(isom(A.')) == A.', 'all'), 'miso/isom fails on tall matrix')

A = A(:,1:2); % Make A square by discarding a column.

check(all(miso(isom(A)) == A, 'all'), 'miso/isom fails on square matrix')

tdisp('Passed');

end

% $Id: test_miso_isom.m 324 2022-04-11 20:22:59Z sangwine $
