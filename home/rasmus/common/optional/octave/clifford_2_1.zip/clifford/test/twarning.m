function twarning(S)
% As warning, but adds a string defining the current algebra as a prefix.
% Used to avoid having to edit complex edits into all the test functions,
% instead warning is changed to twarning everywhere in the test code. Also
% logs the number of warnings issued so that the number can be output at
% the end of the test run.

% Copyright (c) 2017, 2022  Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global twarning_count

warning([current_signature, ': ', S])

twarning_count = twarning_count + 1;

end

% $Id: twarning.m 331 2022-04-23 13:14:29Z sangwine $