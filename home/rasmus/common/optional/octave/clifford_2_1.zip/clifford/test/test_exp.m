function test_exp
% Test code for the Clifford exp and log functions. This code relies on
% matrix isomorphisms and the Matlab expm function for a comparison on the
% isomorphic real matrices.

% Copyright © 2019, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing exp function ...')

global clifford_descriptor %#ok<GVMIS> 

if clifford_descriptor.signature(3) ~= 0
    tdisp(['Cannot test exp/log functions in algebra with r > 0 ' ...
           'due to limitation in iso function.'])
    return
end

% Errors are greater in algebras with larger dimension, so we vary the
% tolerance according to the dimension of the algebra. The lowest value
% of n is 0 (for algebra Cl(0,0)) so we need to index the tolerance
% vector with one greater than n. The largest value of n supported by
% the toolbox is 16. So we need 17 tolerance values.

tolerance = logspace(-5, -3, 17);

T = tolerance(clifford_descriptor.n + 1);

M = cast(clifford_descriptor.m, 'double');

% Test 1. Real multivector data.

m = randm(2,3, 'partial', min(1, 3/M), 'sparse', max(5/16, min(1, 5/M)));
e = exp(m);

for r = 1:size(m, 1)
    for c = 1:size(m, 2)
        compare(expm(isom(m(r, c))), isom(e(r, c)), T, ...
            'clifford/exp failed test 1.');
    end
end

% Test 2. Complex multivector data.

m = complex(randm(3,2, 'partial', min(1, 3/cast(clifford_descriptor.m, 'double'))), ...
            randm(3,2, 'partial', min(1, 3/cast(clifford_descriptor.m, 'double'))));
e = exp(m);

for r = 1:size(m, 1)
    for c = 1:size(m, 2)
        compare(expm(isom(m(r, c))), isom(e(r, c)), 10 .* T, ...
            'clifford/exp failed test 2.');
    end
end

% Test 3. Arrays with more than 2 dimensions.

m = randm(2,2,3, 'partial', min(1, 3/cast(clifford_descriptor.m, 'double')));
e = exp(m);

for r = 1:size(m, 1)
    for c = 1:size(m, 2)
        for p = 1:size(m, 3)
            compare(expm(isom(m(r, c, p))), isom(e(r, c, p)), T, ...
                'clifford/exp failed test 3.');
        end
    end
end

% Test 4. Arrays with multivectors of varying magnitudes. This test
% requires a low tolerance because of inaccuracy with non-unit
% multivectors.

m = randm(2,3, 'partial', min(1, 3/cast(clifford_descriptor.m, 'double'))) .* ...
    randi(3, 2, 3);
e = exp(m);

for r = 1:size(m, 1)
    for c = 1:size(m, 2)
        compare(expm(isom(m(r, c))), isom(e(r, c)), T * 1e3, ...
            'clifford/exp failed test 4.');
    end
end

tdisp('Passed')

% Test 5. Check the logarithm function.

tdisp('Testing log function ...')

% This code was copied from the matrix logarithm (LOGM) test code in
% test_exp.m, as an alternative to the older test based on a check against
% the exponential function. It provides only a basic test of the log
% function. Better tests require a better understanding of issues with the
% logarithm of a multivector. See comments in the log.m file about this,
% especially in relation to the work of Paul Leopardi.

m = randm;

compare(log(inv(m)), complex_conjugate(-log(m)), T, ...
    'Wclifford/log failed test 1.');

tdisp('Passed')

% Older code, commented out because it raises errors in larger algebras.
% Retained here for possible future use, when or if the issues are better
% understood.

% Random data seems to cause errors - meaning the log function needs more
% work. So we test with the clifford_basis, which has integer values and is
% predictable, but a rather weak test. Run times for large algebras are
% excessive, so we limit the basis to 8 elements.
% m = randm('partial', min(1, 3/cast(clifford_descriptor.m, 'double')));

% m = clifford_basis;
% r = size(m, 1);
% m = m(1:max(1, r/8):r); % TODO This spaces out the elements that we test
%                         % throughout the basis, but not taking account of
%                         % the grades.
% 
% compare(m, exp(log(m)), T, 'clifford/exp+log failed test 5.');
% 
% tdisp('Passed');

% $Id: test_exp.m 383 2023-08-21 16:53:13Z sangwine $
