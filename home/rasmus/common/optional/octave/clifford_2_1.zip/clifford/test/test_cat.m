function test_cat
% Test code for the concatenation functions.

% Copyright (c) 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing concatenation ...');

a = randm; b = randm;

check([a, b] == cat(2, a, b), 'Horzcat and cat don''t match on test 1.')
check([a; b] == cat(1, a, b), 'Vertcat and cat don''t match on test 2.')

c = randm(2, 1); d = randm(2, 1);

check([c, d] == cat(2, c, d), 'Horzcat and cat don''t match on test 3.')
check([c; d] == cat(1, c, d), 'Vertcat and cat don''t match on test 4.')

e = randm(2); f = randm(2);

g = cat(3, e, f);

check(g(:, :, 1) == e & g(:, :, 2) == f, 'Cat fails on test 5.')

tdisp('Passed');

end

% $Id: test_cat.m 342 2022-05-06 20:10:44Z sangwine $
