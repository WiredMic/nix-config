function test_adjdet
% Test code for the adjugate and determinant functions

% Copyright (c) 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tdisp('Testing adjugate and determinant functions ...');

% Errors are greater in algebras with larger dimension, so we vary the
% tolerance according to the dimension of the algebra. The lowest value
% of n is 0 (for algebra Cl(0,0)) so we need to index the tolerance
% vector with one greater than n. The largest value of n supported by
% the toolbox is 16. So we need 17 tolerance values.

global clifford_descriptor %#ok<GVMIS> 

tolerance = logspace(-5, -1, 17);

T = tolerance(clifford_descriptor.n + 1);

N = max(1, cast(clifford_descriptor.n, 'double')); % max handles Cl(0,0).
M =        cast(clifford_descriptor.m, 'double');

m = randm('partial', N/M);

% Although adj(m)./det(m) should equal the inverse of m, this is a bad way
% to test, because of the possibility of a small determinant. This is why
% we test using a variation of the idea, but using subtraction of the
% determinant (which if close to zero is going to subtract from a hopefully
% close to zero product, so the test will still work).

compare(abs(adj(m) .* m - det(m) .* e0), 0, T, ...
        'Adjugate/determinant fail test 1')

m = complex(m, randm('partial', N/M)); % TODO The real and imaginary parts
                                       % here will be non-zero in different
                                       % coefficients in general. Better to
                                       % 'align' them in the same
                                       % coefficients. How?

compare(abs(abs(adj(m) .* m - det(m) .* e0)), 0, T, ...
        'WAdjugate/determinant fail test 2')

tdisp('Passed');

end

% $Id: test_adjdet.m 386 2024-02-08 20:28:22Z sangwine $
