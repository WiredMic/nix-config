% Script to compute the volume of a tetrahedron.
% This is a simple demonstration of a CGA calculation.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% 8 November 2022

% Define the coordinates of the four vertices of a tetrahedron in Euclidean
% coordinates, and translational offsets and scale factors (to allow easy
% modification of the script to test out non-regular tetrahedra at
% arbitrary positions).

T = [0, 0, 0]; % Translational offsets (x, y, z)
S = [1, 1, 1]; % Scaling factors       (x, y, z)

% Uncomment these statements to try a non-regular tetrahedron.
% T = [1,   2,   3  ]; % Translational offsets (x, y, z)
% S = [0.7, 1.2, 1.3]; % Scaling factors       (x, y, z)

X = T(1) + S(1) .* [0, 1, 0.5, 0.5];
Y = T(2) + S(2) .* [0, 0, sqrt(3)/2, 1/(2 * sqrt(3))];
Z = T(3) + S(3) .* [0, 0, 0, sqrt(6)/3];

% Calculate the volume using a determinant, as given by Wikipedia at:
% https://en.wikipedia.org/wiki/Tetrahedron#Volume

W = [X; Y ; Z];
disp(['Volume computed using determinant: ', ...
      num2str(abs(det([W(:, 1) - W(:, 2), ...
                       W(:, 2) - W(:, 4), ...
                       W(:, 3) - W(:, 4)])./6)), newline]);

% Plot the tetrahedron on a 3D plot, for a visual verification. 

F1 = [  2 3 4]; % These are index values into X, Y, Z above. There are four
F2 = [1   3 4]; % faces to plot, so we need the coordinates in triples,
F3 = [1 2   4]; % which means omitting one for each face.
F4 = [1 2 3  ];

patch(X(F1), Y(F1), Z(F1), 'red'); hold on, axis equal, grid on, view(3)
patch(X(F2), Y(F2), Z(F2), 'green');
patch(X(F3), Y(F3), Z(F3), 'blue');
patch(X(F4), Y(F4), Z(F4), 'magenta');

% Clifford Algebra calculation. This serves as a reference, based on
% classic vector computation. The three vectors are three edges of the
% tetrahedron, and their wedge product gives the volume of the
% parallelipiped defined by these three vectors. The tetrahedron volume is
% 1/6 of the volume of the parallelipiped.

disp('Initialising Clifford signature (3,0)')
clifford_signature(3,0);

% Define three vectors along three edges of the tetrahedron starting from a
% common vertex. X, Y and Z contain the coordinates of four vertices.

v2 = (X(2) - X(1)) * e1 + (Y(2) - Y(1)) * e2  + (Z(2) - Z(1)) * e3;
v3 = (X(3) - X(1)) * e1 + (Y(3) - Y(1)) * e2  + (Z(3) - Z(1)) * e3;
v4 = (X(4) - X(1)) * e1 + (Y(4) - Y(1)) * e2  + (Z(4) - Z(1)) * e3;

disp(['Result from Clifford wedge of three vectors: ' ...
      char(wedge(v2, v3, v4)/6), newline])

% Now perform the calculation in conformal geometric algebra. Here we
% define the four vertices as conformal points and wedge them together.

conformal_signature(3,0) % Euclidean 3-space.

disp('Four conformal points:')

V1 = conformal_point(X(1), Y(1), Z(1)) %#ok<NOPTS> 
V2 = conformal_point(X(2), Y(2), Z(2)) %#ok<NOPTS> 
V3 = conformal_point(X(3), Y(3), Z(3)) %#ok<NOPTS> 
V4 = conformal_point(X(4), Y(4), Z(4)) %#ok<NOPTS> 

disp([newline 'Volume computed from conformal points:'])

V = right_contraction(wedge(V1, V2, V3, V4, ei), E) / 6 %#ok<NOPTS>

% $Id: tetrahedron.m 366 2022-11-08 16:33:03Z sangwine $
