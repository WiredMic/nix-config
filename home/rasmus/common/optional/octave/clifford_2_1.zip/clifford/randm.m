function S = randm(varargin)
% RANDM   Creates random multivectors. Accepts parameters as for Matlab's
% randn (q.v.), but optionally at the end this function accepts one or two
% name/value pairs in either order. One is 'sparse' and d, where d is a
% numerical value in the range [0,1] as per the density parameter of the
% MATLAB sprandn function (q.v.), specifying that the coefficients of the
% multivector should be sparse matrices. The other pair is 'partial' and k,
% where k is a numeric value equal to or greater than 1/m (where m is the
% number of elements in a multivector) and less than or equal to 1. A
% partial multivector has k * 100% of the multivector elements non-empty.
% The default is that all are non-empty (a complete multivector).

% Copyright © 2013, 2015, 2017, 2021, 2022
% Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

nargoutchk(0, 1)

global clifford_descriptor %#ok<GVMIS>

if isempty(clifford_descriptor)
    error('No Clifford algebra has been initialised.')
end

% Handle the two or four optional last parameters which control creation of
% scanty multivectors (that is where some elements are empty), and/or
% sparse multivectors (where the coefficients are sparse matrices). The
% default is that a full multivector is returned with numeric values in
% every element.

m = cast(clifford_descriptor.m, 'double');

sparse  = false;
partial = false; k = 1;

for j=1:2 % For each of two possible final parameter pairs ...
    if ~isempty(varargin)
        if isa(varargin{end}, 'char') || isstring(varargin{end})
            error(['Name parameter ', varargin{end}, ...
                   ' must be followed by a numeric value'])
        end
    end
    if length(varargin) > 1
        if isa(varargin{end - 1}, 'char') || isstring(varargin{end - 1})
            % The last pair of parameters are character/string followed by
            % what should be a numeric.
            if strcmp(varargin{end - 1}, 'partial')
                if partial
                    error('''partial'' may appear only once')
                else
                    partial = true;
                end
                if ~isnumeric(varargin{end})
                    error('Parameter after ''partial'' must be numeric.');
                end
                k = varargin{end};
                if (k < 1/m) || (k > 1)
                    error(['Parameter after ''partial'' must be in ', ...
                        'range (1/m, 1), where m is the number of ', ...
                        'elements in a multivector in ', ...
                        'the current signature. Given: ', num2str(k)]);
                end
                varargin = varargin(1:end-2); % Delete the 'partial' and k values.
            elseif strcmp(varargin{end - 1}, 'sparse')
                if sparse
                    error('''sparse'' may appear only once')
                else
                    sparse = true;
                end
                if ~isnumeric(varargin{end})
                    error('Parameter after ''sparse'' must be numeric.');
                end
                d = varargin{end};
                if (d < 0) || (d > 1)
                    error(['Parameter after ''sparse'' must be in ', ...
                        'range [0,1]. Given: ', num2str(d)]);
                end
                varargin = varargin(1:end-2); % Delete the 'sparse' and d values.
            end
        end
    end
end

% We have removed from varargin any parameter pairs with 'sparse' or
% 'partial'. Check what is left.

if ~all(cellfun(@isnumeric, varargin))
    error('All parameters apart from ''partial'' and ''sparse'' must be numeric')
end

% Make an index array to select the elements to be populated. If k = 1 this
% will be all elements, otherwise it will be some fraction of the elements
% from at least one element upwards. We must be sure that at least one
% index is chosen, otherwise we would return an empty multivector.

index = randperm(m, fix(k * m));

S = clifford.empty;

if sparse
    F = false;
    for j = index
        assert(length(varargin) == 2, ...
            ['When you specify ''sparse'' you must specify two ', ...
             'numeric values for the size of the sparse arrays,', ...
             'due to the required parameters of the sprandn function.'])
        T = sprandn(varargin{:}, d);
        if any(T(:) ~= 0) % If all are zero, skip, and leave an empty.
            S = put(S, j, T);
            F = true;
        end
    end
    if ~F
        error('Sparsity parameter too low, result is empty multivector')
    end
else
    % Partial is handled here because the index array was created using k,
    % hence there is no need to check for partial. If partial was not
    % specified the default value of k means we get a complete multivector.
    for j = index
        S = put(S, j, randn(varargin{:}));
    end
end

% TODO Write this properly so that the results are normalised and uniformly
% distributed. See the corresponding quaternion function. This has been
% made more difficult by the addition of the sparse and partial options.

% Normalise elements of the result which are non-zero, leaving the zero
% elements as they are (otherwise we would divide by zero, and the results
% would be NaNs. This is especially important given the ability above to
% create sparse/partial multivectors.

if m > 1 % If we are working in Cl(0,0,0), do not normalise!
    NZ = S ~= 0; % Identify the non-zero elements of S, for normalisation.
    S(NZ) = unit(S(NZ)); % Normalise the non-zero multivectors to unit norm.
end

end

% $Id: randm.m 330 2022-04-22 20:56:33Z sangwine $
