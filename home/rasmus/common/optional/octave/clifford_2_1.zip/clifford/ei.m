function result = ei
% EI Vector representing point at infinity (conformal multivectors)

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(0,0), nargoutchk(0,1)

global conformal_descriptor %#ok<*GVMIS> 
        
if isempty(conformal_descriptor)
    error('No conformal algebra has been initialised.')
end

% We need the two vectors ep and eq, where p and q are the first two values
% in the Clifford signature. The formula is (eq + ep)/sqrt(2), where eq is
% the last vector with negative square and ep is the last vector with
% positive square. The formula used is ei = (ep + eq)λ/√2.

s = clifford_signature;

ep = s(1) + 1; % See eo.m for notes on what is done here.
eq = ep + s(2);

result = put(clifford.empty, ep, 1);
result = put(result,         eq, 1);
result = conformal(result) .* conformal_descriptor.lambda ./ sqrt(2);

end

% $Id: ei.m 361 2022-10-26 21:20:26Z sangwine $
