% Clifford Multivector Toolbox
% Version 2.1 9-February-2024
% ---------------------------------------------------------------------
% Copyright © 2013-2024          Stephen J. Sangwine & Eckhard Hitzer
% Email:                         sangwine@users.sourceforge.net
%                                hitzer@icu.ac.jp
% ---------------------------------------------------------------------
%
% The Clifford Multivector Toolbox is a MATLAB class library/toolbox for
% computing with Clifford algebras of arbitrary signature Cl(p,q,r). It
% also supports conformal geometric algebra computations, using Clifford
% algebra for the underlying computations.

% See the file copyright.m for further details.

% $Id: Contents.m 387 2024-02-08 20:53:04Z sangwine $
