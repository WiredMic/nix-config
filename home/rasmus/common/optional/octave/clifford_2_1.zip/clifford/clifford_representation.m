function E = clifford_representation
% CLIFFORD REPRESENTATION. Constructs a matrix representation of the
% Clifford algebra Cl(p,q,r) as selected by the current signature. The
% result is a cell array of sparse basis matrices, each representing in
% matrix form one basis vector in lexical order from e_1 to e_n. The
% representation of every other basis element apart from e_0 can be
% computed from the n vector representations. e_0 is always represented by
% the identity matrix.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer.

% Reference:
% Martin Roelfs and Steven De Keninck,
% 'Graded Symmetry Groups: Plane and Simple',
% arXiv:2107.03771, 8 July 2021.
% 
% Section 10 of this paper sets out a method to construct a unique matrix
% representation of each Clifford algebra, such that the first column of
% the matrix contains the MV coefficients in lexical order. The code below
% is a direct implementation of the method given in the paper, except for
% one thing: for large algebras even the sparse basis matrices would take
% up far too much storage. Consider n = 16. Each sparse matrix would have
% 65536 non-zero elements, and there would be 65536 of these matrices
% returned. That would require 32Gbytes of memory without the index values,
% which is too much. Therefore we return only the representations of the
% vectors e_1 .. e_n. The representation of e_0 is always the identify
% matrix, and representations of all other basis elements can be computed
% as products of the representations of the vectors *provided* that we
% compute them one by one, and use each to compute the permutation which is
% the last step in the paper. We then delete the representation in order to
% save memory, since it can easily be recomputed. So the difference is that
% we compute the permutations as we generate the basis representations,
% rather than leaving it until all basis representations have been
% generated, in order not to have them all in memory at the same time.

narginchk(0, 0), nargoutchk(0, 1)

global clifford_descriptor %#ok<*GVMIS> 
        
if isempty(clifford_descriptor)
    error('No Clifford algebra has been initialised.')
end

% Define the five matrices set out in equation 37 in the reference above.
% Notice that although it would be advantageous to use int8 elements, since
% the values to be represented are in {-1, 0, +1}, we cannot do this
% because Matlab does not support element types other than double or
% logical in a sparse matrix.

I  = speye(2);
IT = sparse([1 0;  0 -1]); % Although these matrices are small, they need
P  = sparse([0 1;  1  0]); % to be sparse because we use them later with
Q  = sparse([0 1; -1  0]); % the Kronecker product and we want the results
R  = sparse([0 0;  1  0]); % to be sparse.

% Define a cell array containing the signature matrices set out in equation
% 38 in the paper. These are also sparse.

S = [repmat(P, [1, clifford_descriptor.signature(1)]), ...
     repmat(Q, [1, clifford_descriptor.signature(2)]), ...
     repmat(R, [1, clifford_descriptor.signature(3)])];

S = mat2cell(S, 2, repmat(2, 1, size(S, 2)./2));

% Define the basis matrices E_i as set out just after equation 38 in the
% paper. We store these also in a cell array, as we did for S above. After
% permutation, these will be the final result returned.

N = cast(clifford_descriptor.n, 'double');

E = cell(1, N);

for i=1:N % For each basis element E_i, to be stored in E ...

    E{i} = S{i}; % Start with the signature matrix, in the middle of the
                 % Kronecker product.

    % The Kronecker product is associative, but not commutative. Therefore
    % we must respect the left/right ordering in the product, but we can
    % carry out the individual products in any computational order.

    for j=1:N-i
        E{i} = kron(E{i}, IT); % These are the product terms on the right.
    end

    for j=1:i-1
        E{i} = kron(I, E{i}); % These are the product terms on the left.
    end
    % TODO Notice that we have not made provision for the alternative terms
    % on the left (I) in cases where E_i and E_j commute. This is because
    % it isn't clear when this case could arise.
end

% Now compute the first N + 1 rows of the permutation matrix.

M = cast(clifford_descriptor.m, 'double');

row = zeros(1, M); % These are the row index, and
val = zeros(1, M); % the value to be stored there.

row(1) = 1; % This is the entry in the permutation matrix corresponding to
val(1) = 1; % e_0, which is represented by an identity matrix.

% See equation 41 in the paper. Without the sparse indexing we would just
% iterate over i and j with two for loops, but that would involve copying
% huge numbers of zeros, which we don't need to do. This is the statement
% that would do the copying: O(i, j) = R{i}(j, 1); Instead we find the
% non-zero elements in each R{i} and assign them to the permutation matrix
% O, at this stage just storing the row index and the value to go there, so
% that we can build the matrix in one step later.

for j=1:N % For each basis vector, starting with e_1.
    [row(j+1), ~, val(j+1)] = find(E{j}(:, 1)); % This will find one nz.
end

% The remaining basis elements are E_12, E_13 etc. and we need to multiply
% together elements of E according to the index string in the descriptor.
% TODO Surely there must be a more efficient way to compute E_12 etc than
% multiplying E_1 by E_2?

Index_Characters = '123456789abcdefg';

IC = Index_Characters(1:N);

assert(length(IC) == length(E));

speyem = speye(M);

for j=N+2:M
    t = clifford_descriptor.index_strings{j}(2:end); % 2:end drops the 'e'.
    R = speyem;
    for k = 1:length(t) % For each character in the index string t ...
        index = strfind(IC, t(k)); % Find the index value of the character.
        % TODO The next line is where time is taken in this function. There
        % is a great deal of duplicated computation. E.g. we compute E_12,
        % then later we need that same product when computing E_123 or
        % E_124, but we recompute E_12 each time. And so on.
        R = R * E{index};
    end

    % Now we have a sparse matrix representing the j-th basis element of
    % the current algebra. Find the permutation matrix entry for this
    % element.

    [row(j), ~, val(j)] = find(R(:, 1)); % This will find one nnz value.
end

% Finally, we apply the permutation that ensures that the representation
% has the elements of the multivector in sequence down the first column,
% with positive signs. The method to do this is set out in the paper in
% equations 41 and 42. The values in the permutation matrix were computed
% above.
% TODO Actually multiplying the matrices here may not be the best way,
% since we could construct a permutation vector of the indices and apply
% that by indexing. See MATLAB documentaion 'Sparse Matrix Operations',
% subsection 'Permutations and Reordering'. However, a much worse problem
% is noted above - duplication of matrix multiplications, and that issue
% should be resolved before any attempt to speed up what happens below.

O = sparse(1:M, row, val);

E = cellfun(@(X) O * X * O.', E, 'UniformOutput', false);

end

% $Id: clifford_representation.m 324 2022-04-11 20:22:59Z sangwine $
