function B = clifford_basis
% CLIFFORD_BASIS Return a column vector containing the basis elements of
% the current algebra. A sparse multivector is returned for algebras with
% n > 5.

% Copyright © 2015, 2022 Stephen J. Sangwine and Eckhard Hitzer.

narginchk(0, 0), nargoutchk(0, 1)

global clifford_descriptor %#ok<GVMIS> 

if isempty(clifford_descriptor)
    error('No Clifford algebra has been initialised.')
end

if clifford_descriptor.n <= 5
    C = [1; zeros(clifford_descriptor.m - 1, 1)];
else
    C = [1; sparse(clifford_descriptor.m - 1, 1)];
end

B = clifford.empty;

for j = 1:clifford_descriptor.m
    B = put(B, j, circshift(C, j - 1));
end

end

% $Id: clifford_basis.m 322 2022-03-21 21:55:28Z sangwine $
