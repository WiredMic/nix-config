function S = conformal_signature(p, q, lambda, eostr, eistr, Estr)
% CONFORMAL_SIGNATURE  Initialises a conformal geometric algebra with
% signature (p,q), λ, and string representations of the origin and infinity
% vectors and their wedge product bivector (for use in displayed output).
% This function also initialises a clifford algebra Cl(p+1, q+1) to provide
% the underlying computations.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global conformal_descriptor; %#ok<GVMIS> 

narginchk(0,6); nargoutchk(0,1);

if all(nargin ~= [0, 2, 3, 6, 7])
    error(['Number of input arguments must be 0, 2, 3, or 6, given ', ...
            num2str(nargin)])
end

if nargin > 0 && nargout > 0
    error('Cannot handle input and output parameters at the same time')
end

if nargout == 1
    if isempty(conformal_descriptor)
        error('No conformal algebra has been initialised')
    end
    S = conformal_descriptor.signature;
    return
end

if nargin == 0 && nargout == 0
    if isempty(conformal_descriptor)
        error('No conformal algebra has been initialised')
    end
    disp(['Conformal algebra (', ...
          num2str(conformal_descriptor.signature(1)), ',', ...
          num2str(conformal_descriptor.signature(2)), ')'])
    disp(['λ value:  ', num2str(conformal_descriptor.lambda)])
    disp(['Origin:   ', conformal_descriptor.strings{1}])
    disp(['Infinity: ', conformal_descriptor.strings{2}])
    disp(['Bivector: ', conformal_descriptor.strings{3}])
    T = clifford_signature;
    if any(conformal_descriptor.signature + 1 ~= T(1:2))
        error('The current Clifford signature is not correct for this conformal algebra')
    else
        disp(['Current Clifford algebra signature (', num2str(T(1)), ...
                                                 ',', num2str(T(2)), ...
                                                 ',', num2str(T(3)), ...
                                                 ')', ...
              ' is correct for this conformal algebra'])
        disp(['Origin   expressed as clifford multivector: ', char(eo)])
        disp(['Infinity expressed as clifford multivector: ', char(ei)])
        disp(['Bivector expressed as clifford multivector: ', char(E)])
    end
    return
end

assert(nargin > 0) % Because we should have dealt with the zero case above.

if nargin < 6 % Supply the default values for the three strings.
    eostr = 'eo';
    eistr = 'e∞';
    Estr  = 'E';
end

if nargin < 3 % Supply the default value for λ.
    lambda = 1;
end

% Check the values of p and q.

if ~isscalar(p) || ~isscalar(q)
    error('The first two (signature) parameters must be scalars.')
end

if ~isnumeric(p) || ~isnumeric(q)
    error('The first two (signature) parameters must be numeric.')
end

if p < 0,       error('The first parameter must not be negative'), end
if p ~= fix(p), error('The first parameter must be an integer'), end

if q < 0,       error('The second parameter must not be negative'), end
if q ~= fix(q), error('The second parameter must be an integer'), end

% Check the value of λ.

if ~isscalar(lambda) || ~isnumeric(lambda)
   error('The value supplied for λ must be a scalar, numeric value.')
end

if lambda == 0
    error('The value supplied for λ must be non-zero')
end

% Check that the strings are sensible. They need to be short strings so
% that output formatting is reasonable.

if ~ischar(eostr) || ~ischar(eistr) || ~ischar(Estr)
    error('The last three parameters must be character strings (char)')
end

if length(eostr) > 5 || length(eistr) > 5 || length(Estr) > 5
    error('One or more of the three string parameters is longer than 5 characters, not accepted')
end

% End of parameter checks, now do the initialising.

disp(['Initialising conformal signature ', ...
      '(', num2str(p), ',', num2str(q), ')'])
disp(['Initialising Clifford  signature ', ...
      '(', num2str(p+1), ',', num2str(q+1), ')'])
clifford_signature(p+1,q+1)

conformal_descriptor.signature = [p, q];
conformal_descriptor.lambda = lambda;
conformal_descriptor.strings = {eostr, eistr, Estr};

end

% $Id: conformal_signature.m 355 2022-10-20 16:16:56Z sangwine $
