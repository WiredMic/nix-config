function y = sparse(x)
% SPARSE  Convert full matrix to sparse matrix.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

y = overloade(mfilename, x);

% $Id: sparse.m 316 2022-03-04 18:16:42Z sangwine $
