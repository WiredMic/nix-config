function X = mat_to_clpqr(Z)
% MAT_TO_CLPQR Multivector array isomorphic to real/complex matrix. Z on
% entry must be a multivector with the real/complex array in the scalar
% part, and the rest empty.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% Given a real/complex matrix, passed as the scalar part of a multivector,
% assumed to be in the correct pattern
% to be an isomorphic matrix, OR a column vector, this private function
% computes the corresponding multivector using the current signature. There
% is an inverse to this function called CLPQR_TO_MAT (q.v.). To understand
% what this function has to handle see CLPQR_TO_MAT.

% The input parameter has to be passed as a multivector with the
% real/complex array in the scalar part, because this is a private function
% and it therefore has to take a multivector argument. Alternatives would
% be to place it in the clifford root folder/directory, but this would lose
% the advantage of a private function (that we can change the
% implementation later if a better idea is found); or to explicitly change
% directory before and after calling the function (so that it is in the
% current directory when called). The latter was the original
% implementation but changing directory (twice) takes too much time.

% Reference:
% Martin Roelfs and Steven De Keninck,
% 'Graded Symmetry Groups: Plane and Simple',
% arXiv:2107.03771, 8 July 2021.
% Section 10 of the paper describes an algorithm which produces a matrix
% with the coefficients of the multivector in lexical order down the first
% column.

global clifford_descriptor %#ok<GVMIS>

Y = part(Z, 1); % Extract the scalar part. We do not check that the rest of
                % the multivector is empty for performance reasons. This is
                % a private function so it can only be called from clifford
                % functions.

[r, c] = size(Y);

% First work out the size of the output multivector, based on the size of
% the input matrix, which could be a block matrix representing a
% multivector array, or it could be a single column of values representing
% a multivector or a column of multivectors.

m = cast(clifford_descriptor.m, 'double');

DY = deinterleave(Y, m);

R = r / m; % Determine the number of rows in the multivector.
assert(fix(R) == R, ...
    'Incorrect number of rows for an isomorphic matrix/vector'); 

if c == 1
    % The input is a column vector.
    C = 1;
else
    % The input must be a matrix or block column vector.
    C = c / m; % Determine the number of columns in the multivector.
    assert(fix(C) == C, ...
        'Incorrect number of columns for an isomorphic matrix/vector'); 
end

Z = DY(:, 1:C); % Extract the first column or column of *blocks* within Y.

% Now create the multivector output array, and assign the non-zero values
% in Z to it.

X = clifford.empty; % This will be created with the current signature.

index = 1:R:R*m; % These are indices into the rows of Z.

flag = false; % This is used to check for a totally empty result, avoiding
              % a call to isempty, which would take a lot more time.
for j=1:m
    k = index(j);
    T = Z(k:k + R - 1, :);
    if any(T, 'all') % If there is any non-zero element in T ...
        X.multivector{j} = T;
        flag = true;
    % else
        % Do nothing because T is all zeros. Leave the j-th element empty.
    end
end

if ~flag
    % No elements of X were written to, so it remains empty. We must not
    % return an empty result, so we put some zeros into the scalar part.
    % But we have to put the correct sort of zeros there, either sparse or
    % full, and if the latter the correct data type.
    if issparse(Y)
        X.multivector{1} = spalloc(R, C, 1); % Set the scalar part to
                                             % sparse zeros.
    else
        X.multivector{1} = zeros(R, C, 'like', Y); % Set the scalar part
                                                   % to full zeros.
    end
end

if c == 1, return, end % The test below is not valid for an input column.

% Now verify that X is correct by computing an isomorphic matrix or block
% column vector from it, and then comparing with Y. This is a costly step,
% but the only way to check the layout of the input array was sensible.

D = clpqr_to_mat(X) - Y; % Compute the difference.

T = max(max(abs(D)));

if T > 1e-10 % FIXME The tolerance here is arbitrary.
    warning(['Input is not an accurate isomorphic representation. ', ...
             'Maximum absolute difference: ', num2str(T)])
end

end

% $Id: mat_to_clpqr.m 372 2023-01-10 15:27:49Z sangwine $