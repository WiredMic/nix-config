function r = expand_zeros(m)
% Private function to expand zero components of a multivector by
% replacing empty components with explicit zeros.

% TODO Should this expand the empty elements into SPARSE explicit zeros?
% This would prevent an explosion in memory usage, but would mean that code
% interrogating the elements would find zeros. The danger is that the
% sparse elements would propagate and make the whole MV sparse, which the
% user might not expect.

% Copyright © 2015 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global clifford_descriptor %#ok<GVMIS> 

r = m; % Copy the input multivector.

if isempty(m)
    return % We do not expand an empty multivector.
end

% The multivector is not empty.

s = size(m);
c = classm(m);

for j = 1:clifford_descriptor.m
    if isempty(r.multivector{j})
        r.multivector{j} = zeros(s, c);
    end
end

end

% $Id: expand_zeros.m 329 2022-04-19 20:56:02Z sangwine $
