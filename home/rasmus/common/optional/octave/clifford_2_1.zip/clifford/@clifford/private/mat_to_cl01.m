function m = mat_to_cl01(M)

% Copyright © 2017 Harry I. Elman (code contributed to the toolbox with
% edits by Steve Sangwine). This code is licensed under the same terms as
% the toolbox itself, for which see the file : Copyright.m for further
% details.

N = deinterleave(M, 2);

[m, n] = size(M);

a = N(1:m/2, 1:n/2);
b = N(m/2 + 1:m, 1:n/2);

clifford_signature(0, 1);
m = clifford(a, b);
end

% $Id: mat_to_cl01.m 359 2022-10-26 16:56:47Z sangwine $