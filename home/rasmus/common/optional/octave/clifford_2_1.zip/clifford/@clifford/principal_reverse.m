function r = principal_reverse(m)
% PRINCIPAL_REVERSE  Computes the principal reverse of a multivector.
% This function produces a result identical to the REVERSE function in
% algebras with q = 0, but if q > 0, there will be sign changes to
% coefficients in which the basis vectors squaring to -1 are factors.

% Copyright © 2019, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% Reference: (this may not be definitive and earliest)
%
% Laville, Guy and Ramadanoff, Ivan; 'Stone-Weierstrass Theorem',
% eprint: arXiv:math/0411090, November 2004. [p.2, principal involution.]

% Note that we have used a more descriptive name, since this involution is
% closely related to the reverse, and is identical to the reverse when q=0.
% Note also that this involution is equivalent to the transpose of the
% isomorphic matrix computed by ISOM (whereas this is true for the REVERSE
% only when q=0). The involution was studied later by Abłamowicz and
% Fauser, and it was they who noted the equivalence with the matrix
% transpose.

% R. Abłamowicz, B. Fauser, 'On the transposition anti-involution in real
% Clifford algebras II: stabilizer groups of primitive idempotents',
% Linear and Multilinear Algebra, 59(12), pp.1359-1381, 2010.
% DOI:10.1080/03081087.2010.517202

narginchk(1, 1), nargoutchk(0, 1)

check_signature(m);

r = reverse(m);

% Now apply sign changes according to the signs of basis elements.

% TODO The method used here is crude, since it carries out multiplication.
% A better method would work directly with the signs of basis elements.

A = clifford_basis;
S = A .* reverse(A); % This is of course a constant for a given signature!
T = part(S, 1);      % This will be a real vector of M = 2^N elements.

for j = 1:length(T)
    switch T(j)
        case -1
            r.multivector{j} = -r.multivector{j};
        case 0
            r.multivector{j} = []; % TODO This should have the correct class.
        case 1
            continue
        otherwise
            error('Sign not in {-1,0,+1}!')
    end
end
end

% $Id: principal_reverse.m 334 2022-04-26 09:47:39Z sangwine $
