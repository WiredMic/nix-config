function matrix = cl00_to_mat(m)

% Copyright © 2017 Harry I. Elman (code contributed to the toolbox with
% edits by Steve Sangwine). This code is licensed under the same terms as
% the toolbox itself, for which see the file : Copyright.m for further
% details.

matrix = part(m, 1);

end

% $Id: cl00_to_mat.m 359 2022-10-26 16:56:47Z sangwine $