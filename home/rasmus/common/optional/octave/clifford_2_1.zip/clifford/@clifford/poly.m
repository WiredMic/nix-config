function [p, u] = poly(m)
% POLY Characteristic polynomial of a clifford multivector. 

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% The method to compute the coefficients of the characteristic polynomial
% of a multivector is given in:
%
% D. S. Shirokov, 'On computing the determinant, other characteristic
% polynomial coefficients, and inverse in Clifford algebras of arbitrary
% dimension', Computational and Applied Mathematics (2021) 40:173.
% DOI: 10.1007/s40314-021-01536-0. [See Theorem 4.]
%
% or alternatively, see:
%
% Kamron Abdulkhaev and Dmitry Shirokov, 'Basis-free Formulas for
% Characteristic Polynomial Coefficients in Geometric Algebras',
% arXiv:2205.13449, 11 September 2022. DOI:10.48550/arXiv.2205.13449
%
% However, Shirokov's definition doesn't match exactly the MATLAB usage in
% the MATLAB POLY function. There is a difference of sign, and Shirokov
% omits the initial coefficient, which is always 1. This code matches the
% MATLAB code, so that the MATLAB POLY function applied to the correct
% isomorphic matrix represenation of m will yield the same polynomial
% coefficients as this function, to within rounding error. The second
% output, which is provided for diagnostic purposes, will be one element
% shorter than the first output.

% This function operates elementwise on m, so if m is an array of
% multivectors, it computes the characteristic polynomial coefficients of
% each element of m, returned in p. The second output is the corresponding
% array of multivectors which are computed in order to find the polynomial
% coefficients. Returning both makes it possible to implement the DET and
% ADJ functions efficiently. The results should be read along the last
% dimension (the preceding dimensions match those of the input multivector
% array). In particular, this means that the outputs will be row vectors in
% the case where the input was a 1-by-1 multivector.

% Note that there is potentially another possible use for this function: to
% compute the characteristic polynomial of a matrix of multivectors
% (cf MATLAB's poly function). One day, maybe.

narginchk(1, 1), nargoutchk(0, 2)

check_signature(m);

global clifford_descriptor %#ok<GVMIS>

% N is defined in Shirokov's paper in equation (50).

N = 2^fix((cast(clifford_descriptor.n, 'double') + 1)/2); 

% Initialise an array for the results. For each element of m, we need to
% return a vector of N elements, so we add another dimension of length 0 to
% the size of m. The coefficients of the polynomial then appear along the
% last dimension, by concatenating them to this dimension at each
% iteration. The calculation is vectorised, all the polynomials are of the
% same length, and require the same steps, so we can compute all of them at
% the same time.

p = cast(ones([size(m), 1]), classm(m)); % This is where the initial 1
                                         % coefficient is inserted.
D = ndims(m);

U = m; % This value is U_1 here, but will be used to store U_2, U_3, .. U_N

u = U; % This is the output array, but later values of U_i will be
       % concatenated with it to create an extra dimension, compared to U.

for k=1:N
    C = (N/k) .* part(U, 1); % This is coefficient C_k.
    U = m .* (U - C);        % The result here is U_(k+1).
    % Now append the coefficient C into the result array, extracting the
    % numeric value from C because the polynomial coefficients must be real
    % and not multivectors.
    p = cat(D + 1, p, -C); % Note the minus sign, for compatibility
                           % with the MATLAB POLY function.
    if nargout == 2 && k < N
        u = cat(D + 1, u, U); % Append the U value to the u output, except
                              % on the last iteration.
    end
end

p = squeeze(p); % Remove singleton dimensions so that we return the minimum
                % sized result compatible with the size of m.
if iscolumn(p)
    p = p.'; % Always return a row vector when the result is a vector.
end

if nargout == 2
    u = squeeze(u); % Ditto for the u output, if present.
    if iscolumn(u)
        u = u.'; % Always return a row vector when the result is a vector.
    end
end

end

% $Id: poly.m 389 2024-02-08 20:55:47Z sangwine $
