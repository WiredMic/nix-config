function tf = isinf(m)
% ISINF Returns a logical array the same size as the clifford multivector m
% showing which array elements, if any, contain Infs (in any multivector
% coefficient).

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

global clifford_descriptor

tf = false(size(m));

% Identify the non-empty elements of the multivector, as these are the only
% ones we need to test for NaNs.

ne = ~cellfun('isempty', m.multivector);

% TODO It ought to be possible to vectorize the loop below using a
% user-defined function.

index = 1:clifford_descriptor.m;

for j = index(ne)
    tf = tf | isinf(m.multivector{j});
end

end

% $Id: isinf.m 325 2022-04-11 20:24:45Z sangwine $
