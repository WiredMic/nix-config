function tf = isfinite(m)
% ISFINITE  True for multivectors with finite elements.  
% (Clifford overloading of standard Matlab function.)

% Copyright © 2023 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% This function returns true if all multivector components of A are finite,
% that is not NaN or infinity.

narginchk(1, 1), nargoutchk(0, 1)

tf = all(cellfun(@isfinite, m.multivector));

end

% $Id: isfinite.m 389 2024-02-08 20:55:47Z sangwine $
