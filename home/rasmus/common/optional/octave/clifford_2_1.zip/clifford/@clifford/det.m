function y = det(m)
% DET  Determinant of multivector or array of Clifford multivectors.
%      Computes the determinant of each multivector in the input.
%      The result is the same size as the input array.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% At present this function does not compute the matrix determinant of a
% matrix of multivectors (because as far as we know, there is no published
% work on this, cf. the case for quaternions - see the file of the same
% name in the Quaternion Toolbox for Matlab - qtfm.sourceforge.net). A
% later update could add another parameter to specify that a matrix
% determinant is needed (and which one if it turns out there is more than
% one definition).

% The coefficients of the characteristic polynomial of a multivector are
% given in, and this paper then uses the characteristic polynomial to
% define the determinant of a multivector:
%
% D. S. Shirokov, 'On computing the determinant, other characteristic
% polynomial coefficients, and inverse in Clifford algebras of arbitrary
% dimension', Computational and Applied Mathematics (2021) 40:173.
% DOI: 10.1007/s40314-021-01536-0. [See Theorem 4.]

p = poly(m); % TODO If the user calls DET and ADJ, poly is called twice to
             % compute the same results. We can avoid this by computing the
             % POLY function outside this function, and passing it in as a
             % second (optional) parameter. If this second parameter is
             % present, use it and do not calculate the polynomial here.
switch ndims(m)
    case 1
        error('Number of dimensions is 1, cannot be!')
    case 2
        % The input array has two dimensions, so it could be a vector or
        % matrix, or a single multivector. We need to handle the matrix
        % case differently, since in the matrix case, the determinant will
        % be a matrix with an entry corresponding to each element of the
        % input matrix, whereas in the other cases the result will be a
        % vector of numeric values (a vector of one element in the case
        % where m is a single multivector).
        if isvector(m)
            y = p(:, end);
            y = reshape(y, size(m)); % TODO Avoid the call on RESHAPE?
        else % m must be a matrix if it isn't a vector.
            y = p(:, :, end);
        end
    case 3
        % The input array is three-dimensional, so the p array will be 4D.
        % Note: this is tricky to use! Each element of the 3D input array
        % has a set of polynomial coefficients, but the last value of each
        % can't be returned as a flat array.
        y = p(:, :, :, end);
    otherwise
        % TODO This could be done, but there doesn't seem to be a general
        % way for arbitrary ndims? So where do we stop?
        error('DET cannot handle arrays with more than 3 dimensions')
end

end

% $Id: det.m 389 2024-02-08 20:55:47Z sangwine $
