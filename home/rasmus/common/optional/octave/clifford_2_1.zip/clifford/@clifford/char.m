function str = char(m, tf)
% CHAR Create character array (string).
% (Clifford overloading of standard Matlab function.)

% TODO Merge this code into DISP and remove char from the toolbox. The
% MATLAB char function does not convert double to a string representation,
% this is done by num2str.

% The second parameter controls whether to output an explicit leading +
% sign. The default is false.

% Copyright © 2013, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 2), nargoutchk(0, 1) 

global clifford_descriptor %#ok<*GVMIS> 

if nargin == 2
   if ~islogical(tf), error('Second parameter must be logical.'), end
else
    tf = false;
end

% There are two cases to be handled. The argument is either an empty or a
% non-empty multivector.

if isempty(m)
    str = '[] multivector'; % This case must be handled first
    return;                 % because an empty multivector is not
end                         % scalar, and the next check would fail.

if ~isscalar(m)
    error('char cannot handle a vector or a matrix.')
end

% TODO We should exercise more careful control over the formatting of the
% result, and/or provide an additional parameter to control it, so that the
% disp function can output a multivector with due regard to the magnitudes
% of the various components. E.g. what happens if one component is very
% small (1e-8 for example), but others are between 0 and 1?

% TODO We should also respect the current display format as used by MATLAB.

f = '%6.4f'; % Control over the format of each numeric value.

str = ''; % Start with an empty string.

last_newline = 0; % Used in the loop below to control output of newlines as
                  % needed (only when the line lengths exceed 5000 chars).

% Set up the pad length which is used to control blank spacing in the
% output so that coefficients align vertically. Until revision 346, the pad
% length was fixed at the length of the longest index string, not counting
% the pseudoscalar index string. Now however, we find the highest grade
% actually present in the multivector, and use the length of that grade's
% index string. The result is a more compact layout for multivectors with
% limited numbers of grades.

pad_length = 0; % This is the default for Cl(0,0).

for i = clifford_descriptor.m:-1:1

    % Search downwards from the pseudoscalar coefficient.
    if isempty(m.multivector{i}), continue; end
    
    % We have found the highest index with a non-empty coefficient.
    pad_length = length(clifford_descriptor.index_strings{i});
    break

end

% Revert to old behaviour for now, until we can merge this code into DISP.

pad_length = length(clifford_descriptor.index_strings{max(clifford_descriptor.m - 1, 1)});

flag = false; % Indicates whether any value has been output.
for i = 1:clifford_descriptor.m
    t = m.multivector{i};
    if ~isempty(t)
        if isreal(t)
            % We are outputting a real value.
            S = plusminus(t);
            if ~flag
                % This is the first value output, and we must output a -
                % sign if the value is negative and a + sign if the tf flag
                % is set.
                if S == '+'
                    if ~tf
                        S = ' ';
                    end
                end
            end
            str = [str ' ' S ' ' num2str(abs(t), f)]; %#ok<*AGROW>
        else
            % We are outputting a complex value, surrounded by parentheses.
            % There is no overall sign in this case, the complex number has
            % signs on the real and imaginary parts, INSIDE the
            % parentheses.
            
            if flag
                % This is not the first value output, so we output a + sign
                % if needed.
                S = plusminus(t);
            else
                S = ' '; % Empty string => no sign.
            end
            rt = real(t);
            if sign(rt) == -1
                srt = '-';
            else
                srt = ' ';
            end
            it = imag(t);
            str = [str ' ' S ' (' srt num2str(abs(rt), f) ' ' ...
                       plusminus(it) ' ' num2str(abs(it), f) 'i)'];
        end
        
        % TODO The padding here is based on the longest index_strings
        % value. When outputting a multivector which does not have high
        % grade elements (e.g. a vector), the padding could be reduced.
        % So, can we devise a better padding algorithm that would adapt to
        % the content of the multivector? YES - find the highest grade
        % present in the MV and then find the length of the index string
        % corresponding to that grade.
        
        str = [str ' ' pad(clifford_descriptor.index_strings{i}, pad_length)];

        % Lines of greater than about 5950 characters seem to cause text
        % overwrite in the MATLAB command window. To prevent this from
        % happening, we insert a newline after each 5000 characters. It
        % would be better if this were done in the DISP function, but that
        % would require the DISP function to scan the string to find where
        % to put the newlines, whereas here we know when we are in between
        % coefficients and can output the newline then.

        if length(str) - last_newline > 5000
            str = [str, newline];
            last_newline = length(str);
        end

        flag = true; % Record that we have output at least one value.
    end
end
end

function S = plusminus(X)
% Extracts the sign of X and returns the character '-', '+'.

if sign(X) == -1
    S = '-';
else
    S = '+';
end
end

function S = pad(X, L)
% Pads the string X to L.

S = [X blanks(L - length(X))];
end

% $Id: char.m 351 2022-10-18 20:07:17Z sangwine $
