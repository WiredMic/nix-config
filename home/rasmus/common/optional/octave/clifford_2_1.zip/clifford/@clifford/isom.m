function M = isom(m)
% ISOM Convert multivector array to block matrix of isomorphic blocks.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

check_signature(m);

if ~ismatrix(m)
    error('Cannot handle arrays with more than 2 dimensions')
end

M = clpqr_to_mat(m);

% The result in M is at present sparse. However, it makes more sense to
% return a full matrix under certain conditions, dependent on the number of
% non-zero entries, and the size of the matrix (not much point in returning
% a sparse matrix if the matrix is small). The conditions are arbitrary of
% course. It might be better to add a second parameter to make the matrix
% sparse, defaulting to a full matrix.

L = length(m.multivector);

[r, c] = size(m);

if nnz(M) > r * c * L^2 / 10 || numel(M) < 1e4
     M = full(M); 
end

end

% $Id: isom.m 328 2022-04-19 10:03:52Z sangwine $