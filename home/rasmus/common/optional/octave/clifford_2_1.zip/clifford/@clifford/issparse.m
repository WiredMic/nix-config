function tf = issparse(m)
% ISSPARSE True for a clifford multivector with (any) sparse components.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

tf = any(cellfun(@issparse, m.multivector));

% $Id: issparse.m 316 2022-03-04 18:16:42Z sangwine $
