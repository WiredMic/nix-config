function Y = clpqr_to_mat(X)
% CLPQR_TO_MAT Real/complex sparse matrix isomorphic to multivector array.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% Given a multivector array, this private function computes an isomorphic
% real/complex (block) matrix. This function is called from the user
% visible function ISOM (q.v.). There is an inverse to this function called
% MAT_TO_CLPQR (q.v.). Error checking on parameters is done in ISOM.

% Reference:
% Martin Roelfs and Steven De Keninck,
% 'Graded Symmetry Groups: Plane and Simple',
% arXiv:2107.03771, 8 July 2021.
% Section 10 of the paper describes the algorithm used here which is based
% on the implementation in CLIFFORD_REPRESENTATION.

global clifford_descriptor %#ok<GVMIS>

persistent E % Computing the representation of the current algebra is an
             % expensive operation, so we keep the result after the first
             % computation, until the algebra changes. We also have to keep
persistent S % the signature, in order to check whether E is still current.

assert(ismatrix(X))

if ~strcmp(classm(X), 'double')
    % This is because the Matlab sparse functions cannot handle non-double.
    % We could convert to double, but better to deal with it at a higher
    % level, rather than inside this private function?
    error(['Private function clpqr_to_mat cannot handle ', ...
           'multivectors with non-double elements'])
end

% Outline. We only need to consider elements of the multivector which are
% non-empty. For each one we need the corresponding E matrix, then we need
% to multiply the coefficient by the E matrix (what if the coefficient is a
% matrix, do we need the kron product? YES but the ordering within the kron
% product matters, the basis representation is the left operand, the MV data
% the right operand). Then add them all up.

ne = ~cellfun('isempty', X.multivector); % This is a logical index into the
                                         % non-empty elements of the
                                         % multivector.
m = length(X.multivector);

[r, c] = size(X);

RM = r * m; % These are the dimensions of the result matrix, Y.
CM = c * m;

if isempty(S) || any(S ~= clifford_descriptor.signature)
    E = clifford_representation; % This gives us matrices for the vector
                                 % basis elements of the current algebra.
    S = clifford_descriptor.signature; % Remember the signature.
% else
    % we use the persistent values of E and S from previous calls.
end

n = length(E);

% We process the multivector in three stages.
%
% 1. The scalar part, for which the matrix representation is an identity
%    matrix.
% 2. The vector part, for each basis element of which the matrix
%    representation is stored in E above.
% 3. The remaining basis elements, which are products of vectors. For these
%    we need to compute the matrix representation by multiplication of
%    selected elements of E above.
%
% In all three stages we compute a Kronecker product of the matrix
% representation with the matching multivector element, which gives us the
% block matrix representation of the multivector.
%
% Where a coefficient of the multivector is empty, we skip it, because
% zeros don't contribute to the resulting matrix representation.
%
% In order to avoid sparse matrix additions, which were used in earlier
% versions of this function up to revision 327, we store the indices and
% values in a cell array at each of the three stages. These cell arrays (B,
% C and D) are then concatenated and used to construct Y in a final step.
% See: MATLAB central answers 203734.

if ne(1) % Stage 1. Deal with the scalar part.

    % The KRON function will always produce a sparse result if one or both
    % inputs is sparse. This may be all zero, e.g. if the multivector X is
    % 0 .* e0, or a zero matrix .* e0. This special case needs careful
    % handling, because the FIND function will return empty in that case.

    T = kron(speye(m), X.multivector{1});

    if nnz(T) == 0

        % The scalar part contains all zeros. Two cases apply here
        % depending on whether the rest of the multivector is empty.

        if nnz(ne(2:end)) == 0  % the rest of the MV is empty ...
            Y = sparse(RM, CM); % but the scalar part contains all zeros.
            return
        else
            B = cell(0,1); % there are non-zero elements in the rest of the
                           % multivector, so continue, with empty in the
                           % scalar part, meaning all zeros.
        end
    else
        [rows, cols, vals] = find(T);

        % Unfortunately, FIND produces a row vector for each of rows, cols,
        % vals, if T is a row vector. This happens if X is a row vector. We
        % have to fix this with a kludge, otherwise Y can be returned with
        % incorrect values due to the contents of B being interpreted
        % wrongly.

        if isrow(rows)
            assert(isrow(cols) & isrow(vals))
            B = {[rows.', cols.', vals.']};
        else
            B = {[rows, cols, vals]};
        end
    end

else
    B = cell(0,1); % The scalar part is empty, but we must not use 0-by-0,
                   % or we will have inconsistent dimensions when we try to
                   % concatenate later with the other two cell arrays. The
                   % value of B here still represents an empty scalar part.
end

% Stage 2. The vector elements of the multivector.

vindex = 2:n+1; % Construct an index array selecting only the non-empty
                % vector elements.

indices = vindex(ne(vindex));

L = length(indices);

C = cell(L, 1);

for j = 1:L

    k = indices(j);

    [rows, cols, vals] = find(kron(E{k-1}, sparse(X.multivector{k})));

    C{j} = [rows, cols, vals];

end

% Stage 3. The remaining elements from e12 to the pseudoscalar are more
% complex to handle, because we need to compute the basis element by
% multiplication of elements in E.

Index_Characters = '123456789abcdefg';

IC = Index_Characters(1:length(E));

speyem = speye(m);

vindex = n+2:m; % Construct an index array selecting only the non-empty
                % bivector, trivector ... pseudoscalar elements.

indices = vindex(ne(vindex));

L = length(indices);

D = cell(L, 1);

for j = 1:L

    k = indices(j);

    t = clifford_descriptor.index_strings{k}(2:end); % 2:end drops the 'e'.

    R = speyem;

    for l = 1:length(t) % For each character in the index string t ...
        index = strfind(IC, t(l)); % Find the index value of the character.
        R = R * E{index}; % R remains sparse because E{index} is sparse.
    end

    % The Kronecker product function converts the multivector element to a
    % sparse matrix, so the result of kron is sparse. FIND gives us the
    % indices and values of the non-zero elements. Summing the results of
    % the kron function directly into Y was incredibly slow, which is why
    % we use the method below of accumulating the indices and values,
    % creating Y outside the loop. 

    [rows, cols, vals] = find(kron(R, X.multivector{k}));

    D{j} = [rows, cols, vals];

end

% We now have three cell arrays B, C and D containing elements of the
% sparse matrix represented as row and column indices and values (each is a
% column vector). Any or all of these cell arrays could be empty. If all
% three are empty, the input multivector must have been empty, which
% requires us to return an empty array, not a sparse matrix of all zeros.

T = [B; C; D]; % Concatenate the three cell arrays.

if isempty(T)
    Y = sparse(0,0); % All three of B, C, D were empty, therefore Y must be
                     % empty (not all zeros).
else
    % Normal case, one or more of B, C, D was not empty.

    U = cell2mat(T);

    Y = interleave(sparse(U(:,1), U(:,2), U(:,3), RM, CM), m);

end

end

% $Id: clpqr_to_mat.m 389 2024-02-08 20:55:47Z sangwine $