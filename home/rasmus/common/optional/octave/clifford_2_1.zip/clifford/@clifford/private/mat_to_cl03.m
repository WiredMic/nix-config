function m = mat_to_cl03(M)

% Copyright © 2017 Harry I. Elman (code contributed to the toolbox with
% edits by Steve Sangwine). This code is licensed under the same terms as
% the toolbox itself, for which see the file : Copyright.m for further
% details.

% Edited 2022 (second time) to use a 4-by-4 complex representation.
% See the comment in cl30_to_mat.m for the reasoning, and the method which
% this code has to invert/undo. The code here is crude, and would not
% extend easily to Cl(4,0), but it works, and it will suffice, even though
% it isn't mathematically elegant.

N = deinterleave(M, 4);

[m, n] = size(N);

% The isomorphic matrix is a block diagonal matrix, and we need the
% quadrants of each block. There is an issue here with copying of the
% diagonal blocks, but it simplifies the coding. So a possible improvement
% is to implement the following two steps in one, at the expense of making
% the code less clear.

% Indexing is clearer if we use logical indices, rather than numerical
% indices, to select the upper and lower diagonal blocks.
% TODO If merged into one step, logical AND could be used.

Upper = [true(1, m/2), false(1, m/2)]; Lower = ~Upper; % Upper/lower half of N.
Left  = [true(1, n/2), false(1, n/2)]; Right = ~Left;  % Left /right half of N.

UD = N(Upper, Left); % These are the upper and lower diagonal blocks of N.
LD = N(Lower, Right);

clear N % No longer needed, save space before the next step.

% Now we need indices into the quadrants of UD and LD
% (which are blocks of the same size).

UR = [true(1, m/4), false(1, m/4)]; LR = ~UR; % Upper and lower rows.
LC = [true(1, n/4), false(1, n/4)]; RC = ~LC; % Left and right columns.

UDUL = UD(UR, LC); % UD block, upper  left quadrant.
UDLL = UD(LR, LC); %           lower  left quadrant.
UDUR = UD(UR, RC); %           upper right quadrant.
UDLR = UD(LR, RC); %           lower right quadrant.

clear UD

LDUL = LD(UR, LC); % LD block, upper left quadrant.
LDLL = LD(LR, LC); % etc.
LDUR = LD(UR, RC);
LDLR = LD(LR, RC);

clear LD

a = ( UDUL + UDLR + LDUL + LDLR)./4;
b = ( UDUL - UDLR - LDUL + LDLR)./4i;
c = ( UDUR + UDLL - LDUR - LDLL)./4i;
d = (-UDUR + UDLL + LDUR - LDLL)./4;
e = (-UDUR + UDLL - LDUR + LDLL)./4;
f =-( UDUR + UDLL + LDUR + LDLL)./4i;
g = ( UDUL - UDLR + LDUL - LDLR)./4i;
h = (-UDUL - UDLR + LDUL + LDLR)./4;

clifford_signature(0, 3);

m = clifford(a, b, c, d, e, f, g, h);

end

% $Id: mat_to_cl03.m 359 2022-10-26 16:56:47Z sangwine $