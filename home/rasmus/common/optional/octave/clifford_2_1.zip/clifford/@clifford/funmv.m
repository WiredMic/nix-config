function Z = funmv(X, f)
% FUNMV Compute an arbitrary function f(X) of a multivector argument X.

% This function will compute any function of a multivector that can be
% represented as a finite power series. The second parameter must be a
% function handle to a function with profile f(x, k) where k is an integer.
% If k is omitted, the function must return f(x). For k = 1, 2, 3, ..., the
% function must return the k-th derivative of f evaluated at x. This is
% based on the corresponding MATLAB function funm (q.v.).

% Copyright © 2023 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% References:
%
% 1. D. S. Shirokov, 'On computing the determinant, other characteristic
%    polynomial coefficients, and inverse in Clifford algebras of arbitrary
%    dimension', Computational and Applied Mathematics (2021) 40:173.
%    DOI: 10.1007/s40314-021-01536-0
%
% 2. Acus, A. and Dargys, A., 'The characteristic polynomial in calculation
%    of exponential and elementary functions in Clifford algebras',
%    Math. Meth. Appl. Sci. (2023), pp. 1–15, DOI: 10.1002/mma.9524.
%    See also Preprint arxiv:2205.11984, 24 May 2022.

narginchk(2,2); nargoutchk(0,1);

assert(isa(f, 'function_handle')) % If it is, then X must be a multivector
                                  % so we don't need to check that (if X
                                  % isn't a multivector, this function
                                  % would not have been called).

g = process(f); % This is needed in order to handle sin, cos, tan, etc.

p = minpoly(X); % Find the minimal polynomial(s) of the multivector(s)
                % in x.
N = prod(size(p, ndims(p))) - 1; % N is the number of roots of p.

% Note that the Clifford POLY function is vectorised, but the MATLAB
% functions that we need from here on are not, so we have to resort to
% iteration over the multivector array X. To make this work for any
% dimension, we reshape X into a vector, carry out the computation, then
% reshape the result to match X. Since we need access to the element of p
% corresponding to each element of the reshaped X, we also need to reshape
% p. We do this so that each row of P (the reshaped p) is one polynomial.

M = numel(X);
p = reshape(p, [M, size(p, ndims(p))]);
Y = reshape(X, M, 1);
Z = clifford(zeros(size(Y)));

for index = 1:M % .. each element of the input argument X, now stored in Y.

    % Y(index) is the multivector we are working on.

    lambda = roots(p(index, :)); % Find the eigenvalues.

    assert(length(lambda) == N);

    % The algorithm used in this function has a variation dependent on
    % whether the eigenvalues are distinct. Therefore we need to know
    % whether the eigenvalues are distinct to within a tolerance. If they
    % are not we keep track of which ones are not-distinct by making a list
    % of their indices.

    lists = {}; % This will store lists of indices for eigenvalues of
                % multiplicity > 1, to enable us to process each group of
                % eigenvalues that are within the tolerance. Each list will
                % be a vector of integers in 1:N.

    tolerance = 1e-3; % TODO Choosing this value is a major problem.

    candidates = 1:N; % This is a list of indices to eigenvalues which we
                      % need to compare. We will delete entries from this
                      % list until it has only one entry.

    while length(candidates) > 1
        left = candidates(1); % This is a value that we need to compare
                              % with all the other values.
        candidates = setdiff(candidates, left);
        right = [];           % This will become a list of other values
                              % that match to within tolerance.

        for k = candidates % each other element ...
            if abs(diff(lambda([left, k]))) < tolerance
                % Two eigenvalues are within the tolerance in the
                % complex plane (or the real number line) so add the right
                % hand index to our list.
                right = [right, k]; %#ok<AGROW>
            end
        end
        if ~isempty(right) % we found some matches ..
            lists = [lists, {[left, right]}];  %#ok<AGROW> 
            candidates = setdiff(candidates, right);
        end
    end

    assert(length(candidates) < 2) % The length could be 1 or 0.

    r = zeros(1, N);
    
    V = fliplr(vander(lambda));
    F = g(lambda, 0);

    if isempty(lists) % this means all eigenvalues have multiplicity = 1.

        % The eigenvalues are distinct. In this case we can use
        % determinants.

        DV = det(V); % This is invariant inside the loop below.
    
        for j = 1:N
            Vj = V;
            Vj(:, j) = F;
            r(j) = det(Vj)./DV;
        end

    else
        % There is at least one eigenvalue with multiplicity > 1.  In this
        % case the determinant of the Vandermonde matrix would be zero, and
        % we cannot divide by it.
        % TODO add reference to the appropriate section of reference 3 when
        % written.

        for j = 1:length(lists) % each set of eigenvalues of multiplicity
                                % > 1 ...
            indices = lists{j}; % These are the indices of one set of
                                % eigenvalues.

            for k = 2:length(indices) % each element after the first ..

                row = indices(k); % The index of the row in V that we need
                                  % to differentiate.

                s = k - 1;

                % Replace the entry in F indexed by row by a derivative
                % f'(X), f''(X), ..., dependent on s, the order of the
                % derivative.

                F(row) = g(lambda(row), s);

                % Shift a row of V left by s places (this corresponds to
                % taking the s-th derivative and scale the values by the
                % factorial ratio shown in reference 3, equation (?).

                sf = [zeros(1, s), factorial(s:N-1)./factorial(s)];

                V(row, :) = circshift(V(row, :) .* sf, -s);

            end

        end

        r = (V\F).';
    end

    % Evaluate the polynomial represented by r, using powers of the
    % elements of Y(index). Some elements of r may be neglible, but not
    % exactly zero, with magnitudes of only several epsilons. Suppressing
    % them can save computation time, both in computing the powers and in
    % multipying the powers by the coefficients.

    L = abs(r) > (10 .* eps); % Index non-negligible elements of r.
    E = 0:N-1;                % All the exponents.

    powers = subsref(Y, substruct('()', {index})).^E(L);

    Z = subsasgn(Z, substruct('()', {index}), sum(r(L) .* powers));
    % Z(index) = sum(r(L) .* powers);

    % TODO We could implement POLYVAL for multivectors and use it here. The
    % problem is that it might be better to implement FILTER and thus make
    % the MATLAB POLYVAL work for multivectors? Working out which way to go
    % isn't trivial.

end

% For many real inputs, the result is theoretically real (example: EXP;
% counter example: LOG). We should return a real result in these cases.
% For complex input, we must return a complex result.

if isreal(X) && all(abs(imag(Z)) < 1e-10)
    Z = real(Z);
end

Z = reshape(Z, size(X));

end

% The function above handles cases like @sin, @cos, @tan, because we can
% provide here versions of these functions that can return derivatives.
% What we do in these cases is to detect that the user-supplied function
% handle f matches one of the supported functions. We then use our own
% function handle rather than the user's. If the handle f doesn't match, we
% return it unchanged, and it is the user's function that is used above.
% This is necessary because the standard MATLAB functions like SIN do not
% implement the second parameter that selects the k-th derivative, whereas
% here we provide local versions that implement the second parameter (and
% we know the derivatives from tables in reference works, or from
% computations with the MATLAB Symbolic Toolbox).

% TODO There is a possibility if the Symbolic Toolbox is installed, that we
% could compute the derivatives symbolically and thus handle a wider range
% of functions. But not all users will have the Symbolic Toolbox installed.

function gh = process(fh)
name = func2str(fh);

supported_functions = {  'sin',   'cos',   'tan', ...
                        'sinh',  'cosh',  'tanh', ...
                        'asin',  'acos',  'atan', ...
                       'asinh', 'acosh', 'atanh'}; % TODO Add EXP, LOG.

found = cellfun(@(x) strcmp(name, x), supported_functions);

if any(found)
    gh = str2func(['local_', supported_functions{found}]);
else
    gh = fh;
end
end

function Y = local_sin(X, k) %#ok<INUSD>
  T = {'sin(X)', 'cos(X)', '-sin(X)', 'cos(X)'};
  Y = eval(T{mod(k, 4) + 1});
end

function Y = local_cos(X, k) %#ok<INUSD>
  T = {'cos(X)', '-sin(X)', '-cos(X)', 'sin(X)'};
  Y = eval(T{mod(k, 4) + 1});
end

function Y = local_sinh(X, k) %#ok<INUSD>
  T = {'sinh(X)', 'cosh(X)'};
  Y = eval(T{mod(k, 2) + 1});
end

function Y = local_cosh(X, k) %#ok<INUSD>
  T = {'cosh(X)', 'sinh(X)'};
  Y = eval(T{mod(k, 2) + 1});
end

% The formulae used below were computed by the Symbolic Toolbox. We can
% easily compute higher order derivatives, if needed.

function Y = local_tan(X, k)
T = tan(X);
switch k
    case 0
        Y = T;
    case 1
        Y = T.^2 + 1;
    case 2
        Y = 2 .* T .* (T.^2 + 1);
    case 3
        Y = 8 .* T.^2 + 6 .* T.^4 + 2;
    case 4
        Y = 8 .* T .* (5 .* T.^2 + 3 .* T.^4 + 2);
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of tan(x) is uncoded.'])
end
end

function Y = local_tanh(X, k)
T = tanh(X);
switch k
    case 0
        Y = T;
    case 1
        Y = 1 - T.^2;
    case 2
        Y = 2 .* T .* (T.^2 - 1);
    case 3
        Y = 8 .* T.^2 - 6 .* T.^4 - 2;
    case 4
        Y = 8 .* T .* (3 .* T.^4 - 5 .* T.^2 + 2);
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of tan(x) is uncoded.'])
end
end

function Y = local_asin(X, k)
switch k
    case 0
        Y = asin(X);
    case 1
        Y = 1 ./ sqrt(1 - X.^2);
    case 2
        Y = X ./ (1 - X.^2).^(3./2);
    case 3
        Y = (2 .* X.^2 + 1) ./ (1 - X.^2).^(5./2);
    case 4
        Y = 3 .* X .* (2 .* X.^2 + 3) ./ (1 - X.^2).^(7./2);
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of asin(x) is uncoded.'])
end
end

function Y = local_acos(X, k)
switch k
    case 0
        Y = acos(X);
    case 1
        Y = -1 ./ sqrt(1 - X.^2);
    case 2
        Y = -X ./ (1 - X.^2).^(3./2);
    case 3
        Y = -(2 .* X.^2 + 1) ./ (1 - X.^2).^(5./2);
    case 4
        Y = -(3 .* X .* (2 .* X.^2 + 3)) ./ (1 - X.^2).^(7./2);
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of acos(x) is uncoded.'])
end
end

function Y = local_atan(X, k)
switch k
    case 0
        Y = atan(X);
    case 1
        Y = 1 ./ (X.^2 + 1);
    case 2
        Y = -(2 .* X) ./ (X.^2 + 1).^2;
    case 3
        Y = (2 .* (3 .* X.^2 - 1)) ./ (X.^2 + 1).^3;
    case 4
        Y = -(24 .* X .* (X.^2 - 1)) ./ (X.^2 + 1).^4;
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of atan(x) is uncoded.'])
end
end

function Y = local_asinh(X, k)
switch k
    case 0
        Y = asinh(X);
    case 1
        Y = 1 ./ sqrt(X.^2 + 1);
    case 2
        Y = -X ./ (X.^2 + 1).^(3/2);
    case 3
        Y = (2 .* X.^2 - 1) ./ (X.^2 + 1).^(5/2);
    case 4
        Y = -(3 .* X .* (2 .* X.^2 - 3)) ./ (X.^2 + 1).^(7/2);
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of asinh(x) is uncoded.'])        
end
end

function Y = local_acosh(X, k)
switch k
    case 0
        Y = acosh(X);
    case 1
        Y = 1 ./ (sqrt(X - 1) .* sqrt(X + 1));
    case 2
        Y = -X ./ ((X - 1).^(3/2) .* (X + 1).^(3/2));
    case 3
        Y = (2 .* X.^2 + 1) ./ ((X - 1).^(5/2) .* (X + 1).^(5/2));
    case 4
        Y = -(3 .* X .* (2 .* X.^2 + 3)) ./ ((X - 1).^(7/2) .* (X + 1).^(7/2));
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of acosh(x) is uncoded.'])        
end
end

function Y = local_atanh(X, k)
switch k
    case 0
        Y = atanh(X);
    case 1
        Y = -1 ./ (X.^2 - 1);
    case 2
        Y = (2 .* X) ./ (X.^2 - 1).^2;
    case 3
        Y = -(2 .* (3 .* X.^2 + 1)) ./ (X.^2 - 1).^3;
    case 4
        Y = (24 .* X .* (X.^2 + 1)) ./ (X.^2 - 1).^4;
    otherwise
        error(['Unimplemented: ', ...
            num2str(k), '-th derivative of atanh(x) is uncoded.'])        
end
end

% $ID$