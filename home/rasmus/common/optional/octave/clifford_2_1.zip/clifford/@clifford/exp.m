function Y = exp(X)
% EXP Exponential of the elements of a multivector array.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2017 Harry I. Elman
% (code contributed to the toolbox with edits by Steve Sangwine).
% This code is licensed under the same terms as the toolbox itself, for
% which see the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

% TODO Consider whether an explicit formula could be used in the two and
% three-dimensional cases. Beware - idempotents and nilpotents may need
% special treatment, which is not the case with the exponential series. The
% following reference gives formulae, which would need checking and testing
% against the code below:
%
% James M. Chappell, Azhar Iqbal, Lachlan J. Gunn, Derek Abbott
% Functions of Multivector Variables, PLOS One.
% doi:10.1371/journal.pone.0116943

% The method used here is a Taylor series, evaluated using Horner's rule.
% This works for any algebra. However, for best accuracy it needs to be
% applied to multivectors with approximately unit modulus. Therefore we
% normalise each element of the multivector Y before computing the series,
% then compensate afterwards by raising to a power. We choose the power to
% be a power of two so that we can implement the raising by successive
% squaring. This is complicated by the fact that different elements of the
% multivector will have different moduli and will need to be squared
% different numbers of times.

% Find the largest power of 2 less than the absolute value of each element
% of the multivector Y, and divide the multivector by these powers.

P = fix(log2(abs(X)));
P(P < 2) = 1; % Ensure that we don't use negative or zero powers.
W = X ./ P;

% The exponential series coefficients are 1/factorial(k). This value is
% less than epsilon (for double precision) for k > 18. Therefore the value
% of the last coefficient compared to the first (which is unity) is less
% than epsilon. This provides a sound basis for the choice, but it requires
% that the multivector X have unit norm (since a large norm would result in
% large norms for higher powers of X). We have approximately dealt with
% this above by scaling, but since the norm may not be unity, we add in two
% extra iterations of the loop, hence N is 20, not 18.

N = 20;

T = e0 .* ones(size(X)); % This is for intermediate results.
Y = T;

for k = 1:N
    T = T .* (W / k);
    Y = Y + T;
end

% Now square up the result to compensate for the scaling down that we did
% above. At each step we find the elements in P that are greater than 1 and
% square the corresponding elements of Y, then reduce the elements of P.

L = P > 1;

while any(L(:))
    % This is a class method, and we cannot use normal array indexing here.
    % We have to use subsasgn/subsref/substruct.
    IX = substruct('()', {L});
    Y = subsasgn(Y, IX, subsref(Y, IX).^2); % Y(L) = Y(L).^2;
    P(L) = P(L)./2;
    L = P > 1;
end

end

% $Id: exp.m 321 2022-03-21 21:31:17Z sangwine $
