function show(m)
% SHOW   Displays the components of a multivector (array).

% Copyright © 2013 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

show_internal(inputname(1), m);

% $Id: show.m 271 2021-07-11 19:54:47Z sangwine $
