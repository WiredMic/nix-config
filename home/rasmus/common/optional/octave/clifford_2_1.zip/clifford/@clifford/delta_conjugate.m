function r = delta_conjugate(u, j)
% DELTA_CONJUGATE Delta conjugation of a clifford multivector. The first
% parameter must be a multivector, the second an integer denoting the
% 'order' of the conjugation (j = 1, 2, 3, 4, ...).

% Copyright © 2021 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% This conjugation is defined in:
%
% D. S. Shirokov, 'On computing the determinant, other characteristic
% polynomial coefficients, and inverse in Clifford algebras of arbitrary
% dimension', Computational and Applied Mathematics (2021) 40:173.
% DOI: 10.1007/s40314-021-01536-0. [See page 5, Definition 3, equation 12.]
%
% For j==1 the result will be identical to the grade involution, for j==2
% the result will be identical to the reverse. Note that in general, this
% function is not an involution but a form of conjugation.

narginchk(2, 2), nargoutchk(0, 1)

if ~isa(u, 'clifford')
    error('First parameter must be a multivector')
end

check_signature(u);

if ~isscalar(j) || ~isnumeric(j) || fix(j) ~= j
    error('Second parameter must be an integer scalar')
end

% Check that j has a sensible value for the current algebra. Definition 3
% in Shirokov's paper defines the range of values as 1:m where m=log2(n) +
% 1, and n is the number of vectors in the current algebra. NB: n has the
% same meaning as in our clifford_descriptor, but m does not! Since the
% largest value of n supported by this toolbox is 16, the largest
% acceptable value for j is 5 (this applies only when n == 16, since the
% value of log2(15) + 1 is 4.9069, which is less than 5).

if j < 1 || j > 5 % This is a check on all possible values of j independent
                  % of the current algebra.
    error('Acceptable range for second parameter is 1:5')
end

global clifford_descriptor %#ok<GVMIS> 

if j > log2(cast(clifford_descriptor.n, 'double')) + 1
    warning(['Value of second parameter is too large: some of ', ...
             'the grades to be negated do not exist in current algebra'])
end

% Now we use Shirokov's formula (12) to determine which grades from 1 to n
% need to be negated.
% TODO This method should eventually be consigned to the test code, and a
% faster method should be implemented here, perhaps based on a table lookup
% or a switch statement for each value of j (since there are only 5
% acceptable values). Then the faster code can be verified against this
% code running in the test suite.

g = 1:clifford_descriptor.n; % These are all the grades.

% Now test each grade against Shirokov's formula, and remove from g any
% where the formula does not produce a negative sign. This leaves a list of
% grades that need to be negated.

j2 = 2^(j-1);

neg = false(size(g));

for k = 1:length(g)
    neg(k) = (-1)^C(k, j2) == -1;
end

r = involution(u, g(neg)); % Negate by grade using private function.

end

% Calculation of C. We do this ourselves rather than using the Matlab
% nchoosek function because we need to handle the case where i > k, and
% Matlab's function barfs at this with an error, instead of returning zero
% as Shirokov specifies. NB This is not vectorised, deliberately kept simple.

function y = C(k, i)
  if i > k
      y = 0;
  else
      y = factorial(k) ./ (factorial(i) .* factorial(k - i));
  end 
end

% $Id: delta_conjugate.m 337 2022-04-29 19:57:13Z sangwine $
