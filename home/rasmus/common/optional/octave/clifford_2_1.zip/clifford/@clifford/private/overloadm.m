function R = overloadm(F, Q)
% Private function to implement overloading of matrix Matlab functions.
% Called to apply the function F to the multivector array Q by operating on
% an isomorphic matrix representation of Q. F must be a string, giving the
% name of the function F. The calling function can pass this string using
% mfilename, for simplicity of coding.

% Copyright © 2019, 2022 Stephen J. Sangwine and Eckhard Hitzer.
% Originally based on a similar function in the Quaternion Toolbox for
% Matlab. See the file : Copyright.m for further details.

S = clifford_signature;

H = str2func(F); % A handle to the function designated by F.

P = H(iso(Q));

clifford_signature(0,0);

R = iso(P .* e0, S(1), S(2));

% $Id: overloadm.m 389 2024-02-08 20:55:47Z sangwine $
