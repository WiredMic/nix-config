function M = cl30_to_mat(m)

% Copyright © 2017 Harry I. Elman (code contributed to the toolbox with
% edits by Steve Sangwine). This code is licensed under the same terms as
% the toolbox itself, for which see the file : Copyright.m for further
% details.

% Edited 2022 (second time) to use a complex 4-by-4 representation, in
% order that the isomorphic matrix should have the same characteristic
% polynomial as the multivector computed by Shirokov's method (see the POLY
% function). The representation used below is computed in accordance with
% the algorithm given by Shirokov [page 18, after equation (50)]. Note that
% there is a typo in the article - in the last displayed equation at the
% foot of page 18, i^k should read i^(k+1) in both elements of the matrix
% at right.
%
% D. S. Shirokov, 'On computing the determinant, other characteristic
% polynomial coefficients, and inverse in Clifford algebras of arbitrary
% dimension', Computational and Applied Mathematics (2021) 40:173.
% DOI: 10.1007/s40314-021-01536-0.

a = part(m, 1);
b = part(m, 2);
c = part(m, 3);
d = part(m, 4);
e = part(m, 5);
f = part(m, 6);
g = part(m, 7);
h = part(m, 8);

M = interleave(blkdiag([ a + b,  c + e; ...
                         c - e,  a - b], ...
                       [ a - b, -c + e; ...
                        -c - e,  a + b]) + ...
               blkdiag([-g - h,  d + f; ...
                        -d + f,  g - h], ...
                       [-g + h, -d + f; ...
                         d + f,  g + h]) .* 1i, 4);
end

% $Id: cl30_to_mat.m 359 2022-10-26 16:56:47Z sangwine $
