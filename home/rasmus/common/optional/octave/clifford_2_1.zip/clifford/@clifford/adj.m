function y = adj(m)  
% ADJ  Adjugate of multivector or matrix of Clifford multivectors.
%      Computes the adjugate of each multivector in the input.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% The coefficients of the characteristic polynomial of a multivector are
% given in the paper below, and it then uses the characteristic polynomial
% to define the adjugate of a multivector which is another multivector:
%
% D. S. Shirokov, 'On computing the determinant, other characteristic
% polynomial coefficients, and inverse in Clifford algebras of arbitrary
% dimension', Computational and Applied Mathematics (2021) 40:173.
% DOI: 10.1007/s40314-021-01536-0. [See Theorem 4.]

[p, u] = poly(m); % TODO See note in DET about avoiding the polynomial
                  % calculation.

global clifford_descriptor %#ok<GVMIS>

N = length(u); % This corresponds to the N in Shirokov's paper (eqn 50), as
               % it indexes the last element of u.
if N == 1
    % Check that we are in Cl(0,0), and if so return an array of -1 the
    % same size as m.
    if all(clifford_descriptor.signature == 0)
        y = -clifford(ones(size(m), classm(m)));
        return
    else
        error('N value is one, but signature is not Cl(0,0), unable.')
    end
end

p = -p; % This sign change is needed because the POLY function returns
        % a negated result compared to Shirokov, in order to agree
        % with the MATLAB POLY function. We use Shirokov's formula below,
        % and negating here means that the sign required for Shirokov's
        % formula is correct.

switch ndims(m)
    case 1
        error('Number of dimensions is 1, cannot be!')
    case 2
        % The input array has two dimensions, so it could be a vector or
        % matrix, or a single multivector. We need to handle the matrix
        % case differently, since in the matrix case, the adjugate will be
        % a matrix with an entry corresponding to each element of the input
        % matrix, whereas in the other cases the result will be a vector of
        % multivector values (a vector of one element in the case where m
        % is a single multivector).
        if isvector(m)
            % y = p(:, N - 1) - u(:, N - 1);
            y = p(:, end - 1) - subsref(u, substruct('()', {':', N - 1}));
            y = reshape(y, size(m)); % TODO Avoid the call on RESHAPE?
        else % m must be a matrix if it isn't a vector.
            % y = p(:, :, N - 1) - u(:, :, N - 1);
            y = p(:, :, end - 1) - ...
                subsref(u, substruct('()', {':', ':', N - 1}));
        end
    case 3
        % The input array is three-dimensional, so the p array will be 4D.
        % Note: this is tricky to use! Each element of the 3D input array
        % has a set of polynomial coefficients, but the last value of each
        % can't be returned as a flat array.
            % y = p(:, :, :, N - 1) - u(:, :, :, N - 1);
            y = p(:, :, :, end - 1) - ...
                subsref(u, substruct('()', {':', ':', ':', N - 1}));
    otherwise
        % TODO This could be done, but there doesn't seem to be a general
        % way for arbitrary ndims? So where do we stop? Surely we could
        % handle this by reshaping the input array to a vector? Then
        % reshape the result array back?
        error('ADJ cannot handle arrays with more than 3 dimensions')
end

end

% $Id: adj.m 389 2024-02-08 20:55:47Z sangwine $
