function r = void(m)
% Private function to void the elements of a multivector. This function
% makes it possible to construct an output parameter within a class
% function that has the same subclass as an input parameter, but with empty
% coefficients. The signature is also, of course, preserved.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

r = m; % Copy the input multivector, including any subclass fields.

% Replace the multivector element of m with an empty cell array of the same
% component class as m (e.g. 'double', 'single').

r.multivector = clifford.empty(classm(m)).multivector;

end

% $Id: void.m 355 2022-10-20 16:16:56Z sangwine $
