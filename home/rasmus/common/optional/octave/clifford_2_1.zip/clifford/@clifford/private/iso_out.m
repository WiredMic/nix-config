function m = iso_out(M, path)

% Copyright © 2017 Harry I. Elman (code contributed to the toolbox with
% edits by Steve Sangwine). This code is licensed under the same terms as
% the toolbox itself, for which see the file : Copyright.m for further
% details.

% TODO This code depends on the elements of path being of the form
% 'fname(m)' where fname is the name of a function. That is the parameter
% passed to the function is hard wired into the string in path. While this
% works, it would be better to use eval(['instruction', '(m)']) so that the
% parameter name is local to this function. Ditto in the iso_in function.

path = flip(path);
m = M;
for instruction_count = 1:numel(path)
    instruction = path{instruction_count};
    % disp(instruction)
    m = eval(instruction);
end

end

% $Id: iso_out.m 314 2022-03-01 21:23:22Z sangwine $