function r = nil(m)
% Private function to replace the elements of a multivector with nil. This
% function makes it possible to construct an output parameter within a
% class function that has the same subclass as an input parameter, but with
% zeros in the scalar part (of the same size as m). The signature is also,
% of course, preserved.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

r = void(m); % Copy the input multivector, including any subclass fields,
             % and set all elements to empty.

% Replace the first multivector element of m with an array of zeros of the
% same size and component class as m.

r.multivector{1} = zeros(size(m), classm(m));

end

% $Id: nil.m 355 2022-10-20 16:16:56Z sangwine $
