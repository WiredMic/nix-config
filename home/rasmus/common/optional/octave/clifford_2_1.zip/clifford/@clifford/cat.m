function r = cat(dim, varargin)
% CAT Concatenate arrays.
% (Clifford overloading of standard Matlab function.)

% Based on and adapted from the
% Quaternion Toolbox for Matlab function of the same name.
% Copyright © 2005, 2009 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.
% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer.

narginchk(3, inf), nargoutchk(0, 1)

if ~isnumeric(dim)
    error('First parameter must be numeric.')
end

a = clifford(varargin{1}); % The call to the class constructor ensures
b = clifford(varargin{2}); % that a and b are both multivectors, even if
                           % the first or second varargin parameter was
                           % something else. Calling the constructor
                           % exploits the error checks there, that would
                           % be complex to include here for handling rare
                           % problems like catenating strings with
                           % multivectors.
check_signature(a);
check_signature(b);

% Now what we have to do is apply the MATLAB CAT function to the elements
% of the multivectors a and b (any other arguments are dealt with by
% recursive call at the end). Empty elements are the main complication,
% since we need to construct explicit zeros where one element is empty, but
% the other isn't. Where both are non-empty there is no difficulty, if both
% are empty, we leave the result empty. So there are four cases to deal
% with.

ea = cellfun('isempty', a.multivector);
eb = cellfun('isempty', b.multivector);

sa = size(a);
sb = size(b);

ca = classm(a);
cb = classm(b);

r = a; % Copy the first multivector argument. This is easier than creating
       % an empty result, because it will have the same element class as a.

global clifford_descriptor %#ok<GVMIS> 

for j=1:clifford_descriptor.m
    if ea(j) && eb(j)
        % Both elements are empty. Nothing to do, as we have already copied
        % the empty element of a to r.
        continue
    elseif ~ea(j) && ~eb(j)
        % Both elements are non-empty. Apply the MATLAB CAT to them.
        r.multivector{j} = cat(dim, a.multivector{j}, b.multivector{j});
    elseif ea(j) && ~eb(j)
        % One element is empty and must be substituted by explicit zeros.
        r.multivector{j} = cat(dim, zeros(sa, ca), b.multivector{j});
    elseif ~ea(j) && eb(j)
        % One element is empty and must be substituted by explicit zeros.
        r.multivector{j} = cat(dim, a.multivector{j}, zeros(sb, cb));
    else
        error('Impossible situation!')
    end
end

if nargin > 3
    r = cat(dim, r, varargin{3:end});    
end

% TODO Consider whether we need to call suppress_zeros here. In theory, no,
% because the input arguments should not contain explicit zeros, so the
% zeros we may have concatenated above would not result in entirely zero
% elements.

end

% $Id: cat.m 340 2022-05-04 21:21:11Z sangwine $
