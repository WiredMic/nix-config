function Y = sqrt(X)
% SQRT Square root of the elements of a multivector array.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2018, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

check_signature(X);

S = get_signature(X); p = S(1); q = S(2);

if S(3) ~= 0
    error(['Cannot compute square roots in algebras ', ...
           'with basis elements that square to zero.'])
end

% The method used here is based on isomorphism with real/complex matrices
% and the matrix square root. We are forced to operate on one element of
% the input array at a time because of this.
% TODO Maybe a better, direct, multivector algorithm is possible?

% Convert the input array to a column vector of multivectors and then to an
% isomorphic block matrix of reals/complexes. We do it in this way and not
% by converting the multivectors one-by-one as the computation of the
% isomorphism requires switching of algebras which can be very
% time-consuming.

M = iso(reshape(X, [numel(X), 1]));
[r, c] = size(M);

N = min(r, c); % This is the size of the blocks within M.

% Now compute the matrix square root of each of the blocks. There is a
% complication here: if the matrix P whose matrix square root is to be
% computed, has negative eigenvalues, then we need to adjust the formula
% for the square root to ensure that the result has the correct layout of
% coefficients, otherwise the multivector result will not be a correct
% square root. Prior to release 1.7 when changes were made to the
% isomorphisms this problem was avoided by careful choice of the matrix
% representations. The negative eigenvalue issue is covered in:
%
% Paul Leopardi, 'Approximating functions in Clifford algebras: What to do
% with negative eigenvalues', Australian Mathematical Society Meeting,
% Adelaide, September 2009. [PDF presentation slides, slide 18.] Available:
% https://maths-people.anu.edu.au/~leopardi/  ...
%         AGACSE-2010-Leopardi-clifford-functions-long-talk.pdf

for j = 1:N:r - N + 1
    V = j:j + N - 1;
    P = M(V, :);
    E = eig(P); % This is of course, an expensive step to avoid problems
                % with negative eigenvalues, but for now there is no other
                % way!
    if any(real(E) < 0)
        % The formula here is due to Paul Leopardi (see above), and fixes
        % the case where E has some negative eigenvalues.
        Q = (1 + 1i) .* sqrtm(-1i .* P) ./ sqrt(2);
    else
        assert(~any(real(E) == 0), ...
            'Imaginary eigenvalues found, cannot deal with!');
            % If there are imaginary eigenvalues, Paul Leopardi's slides
            % referenced above suggest a solution - but do not specify how
            % to find that solution - a value for phi, on slide 18.
        Q = sqrtm(P); % No negative or imaginary eigenvalues, no problem!
    end
    M(V, :) = Q;
end

% Compute the inverse isomorphism to convert back from real/complex blocks
% to multivectors, and reshape the result back to the size of the input
% array.

clifford_signature(0,0);

Y = reshape(iso(M .* e0, p, q), size(X));

end

% $Id: sqrt.m 372 2023-01-10 15:27:49Z sangwine $
