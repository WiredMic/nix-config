function c = hip(a, b)
% HIP  Hestenes inner product

% This product was defined by David Hestenes but the implementation here is
% based on a formula (2.9) given by Leo Dorst, who also defined the inner
% product provided in this toolbox as DIP (q.v.):
%
% Leo Dorst, 'The inner products of geometric algebra', ch. 2, pp. 35-46,
% in: L. Dorst, C. Doran, J. Lasenby, 'Applications of geometric algebra in
% computer science and engineering', Birkhauser, Boston, 2002.
% DOI: 10.1007/978-1-4612-0089-5.

% Copyright © 2018 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global clifford_descriptor %#ok<GVMIS> 

ma = isa(a, 'clifford');
mb = isa(b, 'clifford');

if ma, check_signature(a); end
if mb, check_signature(b); end

if ma && mb
    
    % Both arguments are multivectors.
    
    if ~strcmp(class(a), class(b))
        error(['Both arguments must be of the same subclass, found: ', ...
                class(a), ' ', class(b)])
        % TODO We could overload this function for conformal as we have
        % done for wedge, so that the combination of a conformal with a
        % clifford can be computed. But for now a workaround is to convert
        % the clifford to a conformal, like this: hip(conformal(x), y). If
        % this is done, it may be possible to extract common code into a
        % private function.
    end

    c = nil(a); % Create a scalar zero of the same subclass, size and
                % component class as a (b would do just as well).

    N = cast(clifford_descriptor.n, 'int32'); % We need this in signed form
                                              % because s-r may be negative.

    for r = 1:N % Iterate over all grades apart from 0.
        [ar, ea] = grade(a, r); if ea, continue; end
        for s = 1:N % Iterate over all grades apart from 0.
            [bs, eb] = grade(b, s);               if eb, continue; end
            [g,  eg] = grade(ar .* bs, abs(s-r)); if eg, continue; end
            c = c + g;
        end
    end
 
else

    % One of the arguments is not a multivector. If it is numeric, we can
    % handle it. For simplicity we promote the numeric to a multivector and
    % make a recursive call.
    % TODO Check whether there is a simplification, for example the result
    % is defined to be zero? If so, cut out the computation and return
    % zero.
    
    if ma && isa(b, 'numeric')
        c = hip(a, clifford(b));
    elseif isa(a, 'numeric') && mb
        c = hip(clifford(a), b);
    else
        error('Hestenes inner product of a Clifford multivector with a non-numeric is not defined.')
    end
end

end

% $Id: hip.m 347 2022-10-17 19:08:03Z sangwine $
