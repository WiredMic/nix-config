function X = sqrtm(A)
% SQRTM  Matrix square root.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

check_signature(A);

[r, c] = size(A);

if r ~= c
    error('Matrix must be square.')
end

% The method used here is based on isomorphism with a real/complex block
% matrix and the matrix square root. There is a problem if the isomorphic
% matrix has any negative real eigenvalues (the same problem as in the sqrt
% function). The solution implemented below is due to Paul Leopardi:
%
% Paul Leopardi, 'Approximating functions in Clifford algebras: What to do
% with negative eigenvalues', Australian Mathematical Society Meeting,
% Adelaide, September 2009. [PDF presentation slides, slide 18.] Available:
% https://maths-people.anu.edu.au/~leopardi/  ...
%         AGACSE-2010-Leopardi-clifford-functions-long-talk.pdf

% TODO Maybe a better, direct, multivector algorithm is possible?
%      (Long shot, maybe not worth the work involved.)
% The current implementation fails when the matrix produced by the MATLAB
% sqrtm function does not conform to the pattern required of an isomorphic
% matrix representation of a multivector matrix. We don't have any control
% over this, but perhaps we could work out why it happens and add a fix as
% we do for negative eigenvalues.

M = isom(A); % Convert to an isomorphic block matrix of reals or complexes.

F = full(M); % We have to use full here to circumvent a limitation of the
             % eig function. The full matrix may be too big to compute.
E = eig(F);  % We need to check for negative real eigenvalues.
             % Computational cost here unavoidable?

if any(real(E) < 0) % Check for negative real eigenvalues.
    N = sqrtm(-1i * F) * (1 + 1i) / sqrt(2);
else
    assert(~any(real(E) == 0), ...
        'Imaginary eigenvalues found, cannot deal with!'); % TODO Sure?
    N = sqrtm(F);
end

X = miso(N); % Convert the result back to a matrix of multivectors.

% $Id: sqrtm.m 372 2023-01-10 15:27:49Z sangwine $
