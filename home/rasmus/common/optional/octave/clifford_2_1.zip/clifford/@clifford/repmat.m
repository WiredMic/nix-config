function b = repmat(a, varargin)
% REPMAT Replicate and tile an array.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2015 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(2, inf), nargoutchk(0, 1) 

b = overload(mfilename, a, varargin{:});

end

% $Id: repmat.m 343 2022-05-15 19:47:08Z sangwine $
