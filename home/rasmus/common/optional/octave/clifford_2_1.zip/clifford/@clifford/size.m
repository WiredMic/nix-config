function varargout = size(m, dim)
% SIZE   Size of matrix.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2013 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global clifford_descriptor %#ok<GVMIS>

M = clifford_descriptor.m;

% We need to find the size of any non-empty part of the multivector. If
% there is no non-empty part, we need to return the appropriate values for
% the empty parts.

switch nargout
    case 0
        switch nargin
            case 1
                size(m.multivector{find_non_empty})
            case 2
                size(m.multivector{find_non_empty}, dim)
            otherwise
                error('Incorrect number of input arguments.')
        end
    case 1
        switch nargin
            case 1
                varargout{1} = size(m.multivector{find_non_empty});
            case 2
                varargout{1} = size(m.multivector{find_non_empty}, dim);
            otherwise
                error('Incorrect number of input arguments.')
        end
    case 2
        switch nargin
            case 1
                [varargout{1}, varargout{2}] = size(m.multivector{find_non_empty});
            case 2
                error('Unknown command option.'); % Note 1.
            otherwise
                error('Incorrect number of input arguments.')
        end
    otherwise
        switch nargin
            case 1
                d = size(m.multivector{find_non_empty});         
                for k = 1:length(d)
                    varargout{k} = d(k); %#ok<AGROW>
                end
            case 2
                error('Unknown command option.'); % Note 1.                
            otherwise
                error('Incorrect number of input arguments.')
        end
end

    function k = find_non_empty
        % Find the first non-empty element of m and return its index.
        
        k = 1; % The index of the scalar part, default result, applicable
               % if the scalar part is non-empty, OR all elements are
               % empty, in which case the scalar part is as good as any.

        % We first check the scalar part, as if this is non-empty, we can
        % return its index. This short-circuits a lot of searching done
        % below.

        if ~isempty(m.multivector{1})
            return
        end
        
        % The search is broken into 1024 element chunks of the multivector.
        % For algebras up to n = 10, this means the entire multivector is
        % searched in one cellfun operation. For larger algebras the chunks
        % mean that the search terminates if a non-empty element is found,
        % but proceeds through all of the multivector only when the entire
        % multivector is empty.
        
        for j = 1:1024:M
            nempty = ~cellfun('isempty', ...
                    m.multivector(j:min(j + 1023, M)));
            if any(nempty)
               k = find(nempty, 1) + j - 1;
               return
            end
        end
    end
end

% Note 1. Size does not support the calling profile [r, c] = size(q, dim),
% or [d1, d2, d3, .... dn] = size(q, dim). The error raised is the same as
% that raised by the built-in Matlab function.

% $Id: size.m 324 2022-04-11 20:22:59Z sangwine $
