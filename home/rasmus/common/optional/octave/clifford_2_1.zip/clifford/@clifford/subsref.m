function b = subsref(a, ss)
% SUBSREF Subscripted reference.
% (Clifford overloading of standard Matlab function.)

% This function was copied from the Quaternion Toolbox for Matlab (QTFM)
% with modifications to work with matrices of Clifford multivectors.

% Copyright © 2005, 2010 Stephen J. Sangwine and Nicolas Le Bihan.
% Copyright © 2015       Stephen J. Sangwine and Eckhard Hitzer.
% See the file : Copyright.m for further details.

global clifford_descriptor %#ok<GVMIS> 

if length(ss) ~= 1
    error('Only one level of subscripting is currently supported for multivectors.');
end

check_signature(a);

switch ss.type
case '()'
    if length(ss) ~= 1
        error('Multiple levels of subscripting are not supported for multivectors.')
    end
    
    b = a; % Copy the input parameter to avoid calling the constructor.
   
    % To implement indexing, we operate separately on the components.
    
    index = 1:clifford_descriptor.m;
 
    e = cellfun('isempty', a.multivector); % Work out which elements are empty.

    if any(e) % If there are any empty elements, process them.
        % We need to supply explicit zeros, for the subscripted reference
        % to operate on, because we don't know what it will do.
        z = zeros(size(a), classm(a)); 
        for j = index(e) 
            b.multivector{j} = z(ss.subs{:}); % For some reason this cannot
                                              % be done with PUT. TODO Why?
        end
    end

    for j = index(~e) % Process the non-empty elements (the common case).
        t = a.multivector{j};
        b.multivector{j} = t(ss.subs{:}); % For some reason this cannot be
                                          % done with PUT. TODO Why?
    end
case '.'
    error('Structure indexing is not implemented for multivectors.')
case '{}'
    error('Cell array indexing is not valid for multivectors.')
otherwise
    error('subsref received an invalid subscripting type.')
end

b = suppress_zeros(b);

end

% $Id: subsref.m 324 2022-04-11 20:22:59Z sangwine $
