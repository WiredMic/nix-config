function R = complex_conjugate(M)
% COMPLEX_CONJUGATE  Computes the complex conjugate of a multivector.
% This means taking the complex conjugate of each coefficient. Note that
% the CONJ function does not do this, because it must apply the clifford
% conjugate. For reasons, see conj.m.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

check_signature(M);

global clifford_descriptor %#ok<GVMIS> 

% TODO Create the output value R more cleverly, so that if M is from a
% subclass of clifford, we make R of the same subclass.

R = void(M);

% TODO The code below is adapted from private/overload.m. See the notes in
% that function about possible issues and improvements.

for i = 1:clifford_descriptor.m
    if isempty(M.multivector{i})
        R.multivector{i} = M.multivector{i}; % Copy the empty component
                                             % without change.
    else
        R.multivector{i} = conj(M.multivector{i});
    end
end

end

% $Id: complex_conjugate.m 372 2023-01-10 15:27:49Z sangwine $
