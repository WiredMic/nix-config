function Z = power(X, Y)
% .^   Array power.
% (Clifford overloading of standard Matlab function.)

% This function was adapted from the Quaternion Toolbox for Matlab (QTFM),
% with significant new algorithms for the inverse of a multivector,
% referenced below, and new code for integer powers added in 2022.

% Copyright © 2015, 2016, 2022 Stephen J. Sangwine and Eckhard Hitzer.
% See the file : Copyright.m for further details.

narginchk(2, 2), nargoutchk(0, 1)

% This function can handle left and right parameters of the same size, or
% cases where one or other is a scalar.  The general case of a matrix or
% vector raised to a matrix or vector power requires elementwise operations
% and is handled using a general formula using logarithms, even though some
% of the elements of the right argument may be special cases (discussed
% below).

% When the right operand is a scalar, some special cases are handled using
% specific formulae because of the greater accuracy or better speed
% available. For a power of +/- 1/2, the sqrt function is used, with or
% without a reciprocal.

% TODO Another special case that could be handled is an exponent which is
% an array or vector of integer powers, e.g. X.^[2,3,4].

if isscalar(Y) && isnumeric(Y)
    if round(Y) == Y && isreal(Y)
        % Exponent is a real integer.
        if Y < -1
            % Negative powers (excluding -1). Invert the elements of X and
            % call this function recursively on the result with positive Y.
            Z = inverse(X) .^ abs(Y);
        elseif Y == -1
            Z = inverse(X);
        elseif Y == 0
            Z = clifford(ones(size(X), 'like', part(X, 1)));
        elseif Y == 2
            Z = X .* X;
        else
            % Y must be real and greater than zero.
            Z = array_multivector_to_scalar_integer_exponent(X, Y);
        end
    else
        % Non-integer or non-real (complex) case. Deal with square root
        % cases separately in order to use the square root algorithm.

        if Y == 1/2
            Z = sqrt(X);
        elseif Y == -1/2
            Z = sqrt(inverse(X));
        else
            Z = general_case(X, Y);
        end
    end
    
elseif isscalar(X) && isnumeric(Y)

    % X is a scalar, but Y is not (otherwise it would have been handled
    % above).

    if isvector(Y) && all(round(Y) == Y) && isreal(Y) && all(Y >= 0)
        % We have a scalar X, but a vector of real non-negative integers in Y.

        Z = scalar_multivector_to_integer_exponents(X, Y);
    else
        % The general case code will handle this, since it will expand
        % X to the same size as Y before pointwise multiplication.
    
        Z = general_case(X, Y);
    end
else
    
    % Neither X nor Y is a scalar, therefore we have to use the general
    % method, but first we need to check that the sizes of the parameters
    % match, otherwise an error will occur in the pointwise multiply when
    % the logarithm is multiplied by the exponent.
    
    if ~all(size(X) == size(Y))
        error('Matrix dimensions must agree.');
    end
    
    Z = general_case(X, Y);

end

end

function Z = inverse(X)
% Inverse of a multivector, raising to the power -1. The algorithms used
% below for 2 < p+q < 6, were developed by the authors of the toolbox
% during 2015 and 2016. The algorithm for p + q = 6 is due to Acus and
% Dargys in 2017.
%
% References:
%
% Hitzer, E. and Sangwine, S. J., 'Multivector and multivector
% matrix inverses in real Clifford algebras', Applied Mathematics
% and Computation, 311, 15 October 2017, 375-389.
% DOI:10.1016/j.amc.2017.05.027. A preprint is available as:
% Technical Report CES-534, School of Computer Science and
% Electronic Engineering, University of Essex, 21 July 2016,
% available at: http://repository.essex.ac.uk/17282/.
%
% Acus, A. and Dargys, A.,
% The Inverse of a Multivector: Beyond the Threshold p+q=5,
% Advances in Applied Clifford Algebras, July 2018, 28:65.
% DOI: 10.1007/s00006-018-0885-4.
% See also: arXiv:1712.05204, 14 December 2017, 16pp,
% available at https://arxiv.org/abs/1712.05204.

% The following paper offers am alternative way to compute the inverse by
% using a recursive formulation, without isomorphisms. Shirokov shows how
% to compute the functions ADJ and DET (implemented in this toolbox, q.v.)
% such that A.^-1 = ADJ(A)./DET(A).
%
% D. S. Shirokov, 'On determinant, other characteristic polynomial
% coefficients, and inverses in Clifford algebras of arbitrary
% dimension', Computational and Applied Mathematics (2021) 40:173,
% DOI:10.1007/s40314-021-01536-0. (See Theorem 4, equations 57-63.)
% Also available as: arXiv:2005.04015v1 [math-ph] 8 May 2020.

global clifford_descriptor %#ok<GVMIS> 

s = clifford_descriptor.signature;
if s(3) ~= 0
    % Assumed, this has not been proven mathematically ...
    error(['The inverse of a multivector cannot be ' ...
           'computed in an algebra with signature ' num2str(s) ...
           ' because there are basis blades that square to zero.'])
end

% The algorithm for computing the inverse becomes more complicated as we
% add higher grades. To avoid needless function calls in the lower
% algebras, we check the dimensionality of the algebra and choose the
% appropriate method.

check_signature(X);

switch clifford_descriptor.n
    case {1, 2}
        P = conj(X);
    case 3
        % P = conj(X) .* grade_involution(X) .* reverse(X);
        Q = conj(X); P = Q .* involution(X .* Q, 3);
    case 4
        % P = conj(X) .* involution(X .* conj(X), [3,4]);
        Q = conj(X); P = Q .* involution(X .* Q, [3, 4]);
    case 5
        L = conj(X) .* grade_involution(X) .* reverse(X);
        P = L .* involution(X .* L, [1, 4]);
    case 6
        % The algorithm for this case is due to Acus and Dargys, see
        % reference above. In Table 3 of their arXiv preprint, two formulae
        % are given, and the second is stated to be slightly faster. We
        % have coded and tested both, but use the second. Variable names
        % have been adapted to match ours in earlier cases.
        
        X236 = involution(X, [2,3,6]); % A.k.a. reverse(A).
        H = X .* X236;
        
        % First formula.

        % H4 = involution(H, 4);
        % G = (X236 ./ 3) .* ...
        %     (H .* involution(H.^2, [1,4,5]) + ...
        %      2 .* involution(H4 .* involution(H4 .^ 2, [1,4,5]), 4)...
        %     );
        
        % Second formula.
        
        H45 = involution(H, [4,5]);
        P = (X236 ./ 3) .* ...
            (involution(H .* involution(H .* involution(H, [1,5]), 4), [1,5]) + ...
            2 .* involution(H45 .* involution(H45 .* involution(H, [1,4]), 4), [1,4]) ...
            );
    otherwise
        
        % For higher grades we use isomorphisms to represent the
        % multivector in a different algebra, compute the inverse in the
        % different algebra, then map the result back to the current
        % algebra.
                        
        S = get_signature(X); p = S(1); q = S(2); r = S(3);

        if r ~= 0
            error('Cannot handle algebra with r > 0');
        end
        
        if p == 0 && q == 0
            % TODO Avoid the constructor here?
            Z = clifford(power(part(X,1), -1));
            return
        end
        
        % TODO We have available isomorphisms which can add or subtract 8
        % to/from p or q. These could be used below to implement large
        % jumps in signature in one step (although the current
        % implementation is done using the 2x2 matrix and plus/minus 4
        % isomorphisms). E.g. we could move from algebra Cl(0,9) to Cl(0,1)
        % in one step using c2cm8q.
        
        if p ~= 0 && q ~= 0
            % Use an isomorphism with 2x2 matrices, reducing p and q by one
            % each and then computing the matrix inverse. TODO Ideally here
            % we could use arrayfun if this is implemented for multivector
            % arrays. But for now we use iteration, treating X as a
            % one-dimensional array so that we can handle any number of
            % dimensions.
            
            Z = X; % Make a copy of the input array to preallocate.
            for i = 1:numel(X)
                % Z(i) = isop1p1(inv(isom1m1(X(i))));
                S = substruct('()', {i});
                Z = subsasgn(Z, S, ...
                             isop1p1(inv(isom1m1(subsref(X, S)))));
            end
            return
        else
             % One of p or q is zero (we checked above for both equal to
             % zero), so we can't use the matrix isomorphism. Instead we
             % use a p+4,q-4 or p-4,q+4 isomorphism. This doesn't directly
             % enable us to compute the inverse, but it does enable the
             % recursive call to use the matrix isomorphism above.
             
            if p == 0
                Z = isom4p4(power(isop4m4(X), -1));
                return
            else
                assert(q == 0);
                Z = isop4m4(power(isom4p4(X), -1));
                return
            end
        end
        
end
A = X .* P;

R = A - scalar(A); % This should be zero or empty, or close.
M = abs(R) ./ abs(X);
if any(M > 1e-2, 'all')
    warning(['Ill-conditioned multivector: ', num2str(max(M(:)))])
end

% The right division that follows needs to be a numeric division and not a
% multivector division, and we have just checked that all except the scalar
% part of A is zero or close to it.

Z = P ./ part(A, 1);

% Some elements of the result in Z may be NaNs. There are two reasons why
% this may be so:
%
% 1. The corresponding element of X was 0 * e0. In this case we
%    should replace the NaN with Inf, to match what Matlab does with real
%    values.
%
% 2. The corresponding element of X is a divisor of zero. In this
%    case we leave the NaN as is. If we had a function ISDIVISOR as exists
%    in the Quaternion Toolbox for Matlab, we could use it here to confirm
%    the property. But at present we cannot implement this function,
%    because we don't know the formula(s).

N = isnan(Z);

if all(~N, 'all'), return, end % No NaN's found, so return Z as is.

XZ = (X == 0); % Check the elements of X for equality with 0.

% Check that every true element in XZ corresponds to a true element in N,
% meaning that all zeros in X caused a NaN in Z. TODO This may be a
% redundant check, so consider removing it.

assert(all(N(XZ), 'all'), ...
       'Not all elements found to be zero caused a NaN?');

% Set the elements of Z where X was zero to +/- infinity. This is a class
% method, so we cannot do this using normal logical indexing. We use the
% zero values in X to compute the infinities in order to ensure that
% negative zeros result in negative infinities, as in Matlab itself.

XS = part(X, 1); % Extract the scalar part, which contains the zeros.

Z = subsasgn(Z, substruct('()', {XZ}), XS(XZ).^-1); % Z(XZ) = 1/X(XZ);

end

function Z = array_multivector_to_scalar_integer_exponent(X, Y)
% Handles the case of real non-negative scalar integer Y only.

% We use the method of repeated squaring, composing the result as the
% product of selected powers of 2, using the binary representation of Y to
% select the powers, one bit at a time. See, for example:
% https://www.planetmath.org/computingpowersbyrepeatedsquaring

B = flip(dec2bin(Y)); % Express Y as a sequence of bits in binary, least
                      % significant bit on the left at index 1.
L = length(B);        % There will be no leading zeros.

% We use a string of bits for ease of coding, rather than working with a
% numeric representation. We assume that the multivector squaring and
% multiplication will be much more time consuming than the bit twiddling.

% We work sequentially here, so that only one power of X has to be stored
% at a time.

S = X; % First power, X.^1.

for j = 1:L % Find the first non-zero bit in B.
    if B(j) == '1'
        Z = S; % Set Z to the power of X stored in S.
        break % ... and move onto the second loop.
    else
        S = S .* S; % Compute the next power of 2 by
                    % squaring, ready for j+1 in this loop.
    end
end

% Notice that we switch from computing the square at the end of the
% loop (above), to computing the square at the start of the loop
% (below). This avoids us computing a square at the end that we don't
% need, whereas above it enabled us to enter the loop with X as the
% first power.

for k = j+1:L
    S = S .* S;
    if B(k) == '1'
        Z = Z .* S;
    end
end

end

function Z = scalar_multivector_to_integer_exponents(X, Y)
% Handles the case of real non-negative integer vector Y only.
% X must be a scalar (i.e. not an array of multivectors).
% Example: Z = X.^[1:10] to compute the powers 1 .. 10 of X.

Z = clifford(ones([length(Y), 1], classm(X))); % This is X.^0, in a column.

B = fliplr(dec2bin(Y)); % Express each Y as a sequence of bits in binary,
                        % least significant bit on the left in column 1.

C = size(B, 2); % The number of columns in B, the number of bits in each Y.

S = X; % X.^1

for j = 1:C % For each column in B, for each bit in the binary
            % representation of the values in Y.

    % For each non-zero bit in the j-th column, we need to multiply in the
    % current power of X, held in S.

    L = B(:, j) == '1'; % This gives us an array of logical indices into Z.

    % Multiply S into each Z selected by a true value in L. This is a class
    % method, so we have to use substruct etc., and not direct indexing.

    Z = subsasgn(Z, substruct('()', {L}), ...
         subsref(Z, substruct('()', {L})) .* S); % Z(L) = Z(L) .* S;

    if j < C % Don't waste time on this potentially expensive
             % multiplication last time round the loop.
        S = S .* S;
    end
end

Z = reshape(Z, size(Y)); % Make sure we return a row or column, matching Y.

end

function Z = general_case(X, Y)

% We can handle numerics for either X or Y, and multivectors for either or
% both of X and Y. Check the signatures of the multivector parameters to
% make sure they are in the current algebra.

if isa(X, 'clifford')
    check_signature(X);
else
    if ~isnumeric(X)
        error(['Parameters to power function must be numeric or ', ...
               'multivector, found: ' class(X)])
    end
end

if isa(Y, 'clifford')
    check_signature(Y);
else
    if ~isnumeric(Y)
        error(['Parameters to power function must be numeric or ', ...
               'multivector, found: ' class(Y)])
    end
end

Z = exp(log(X) .* Y); % NB log(X) is the natural logarithm of X.
                      % (Matlab convention.)                 
end

% $Id: power.m 389 2024-02-08 20:55:47Z sangwine $
