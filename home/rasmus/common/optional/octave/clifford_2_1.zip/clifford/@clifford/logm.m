function X = logm(A)
% LOGM  Matrix logarithm.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

S = clifford_signature;

if S(3) > 0
    % The signature indicates r > 0. For this case we use the isom/miso
    % isomorphism pair, because it seems to work, whereas the iso
    % function does not, reason not fully understood. TODO

    M = isom(A);
    N = logm(M); % TODO Do we need to guard against negative eigenvalues?
    X = miso(N);
else
    % The signature indicates r == 0, and for this we use the iso function.
    % The isom/miso pair cause problems here, with matrices which are not
    % correct isomorphic representations.

    % The method used here is based on isomorphism with a real/complex
    % block matrix and the matrix logarithm. There is a problem if the
    % isomorphic matrix has any negative real eigenvalues (the same problem
    % as in the sqrt function). The solution implemented below is due to
    % Paul Leopardi:
    %
    % Paul Leopardi, 'Approximating functions in Clifford algebras: What to
    % do with negative eigenvalues', Australian Mathematical Society
    % Meeting, Adelaide, September 2009. [PDF presentation slides, slide
    % 18.] Available:
    % https://maths-people.anu.edu.au/~leopardi/  ...
    %         AGACSE-2010-Leopardi-clifford-functions-long-talk.pdf

    M = iso(A);
    F = full(M); % We have to use full here to circumvent a limitation of the
                 % eig function. The full matrix may be too big to compute.
    E = eig(F);  % We need to check for negative real eigenvalues.

    if any(real(E) < 0) % Check for negative real eigenvalues.
        % Use Paul Leopardi's solution, and call this function recursively.
        % We use complex(0,1) and not 1i in case i has been redefined.
        N = logm(-complex(0,1) .* F) + complex(0,1) .* pi ./ 2;
    else
        K = max(abs(imag(E)));
        if K < 1e-8 % Obviously this is arbitrary. FIXME.
            N = logm(F);
        else
            error(['Imaginary eigenvalues found, cannot deal with! ', ...
                   'Maximum magnitude: ', num2str(K)]);
            % If there are imaginary eigenvalues, Paul Leopardi's slides
            % referenced above suggest a solution - but do not specify how
            % to find that solution - a value for phi, on slide 18. So for
            % now we raise an error, but if there is an algorithm to find a
            % value for phi, it needs to go here instead of the error.
        end
    end

    clifford_signature(0,0);

    X = iso(N .* e0, S(1), S(2));

end

% $Id: logm.m 389 2024-02-08 20:55:47Z sangwine $
