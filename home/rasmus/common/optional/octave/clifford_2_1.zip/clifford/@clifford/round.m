function a = round(q)
% ROUND Round towards nearest integer.
% (Clifford overloading of standard Matlab function.)

% Copied from the Quaternion Toolbox for MATLAB (QTFM).

% Clifford modifications:
% Copyright © 2006 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1) 

a = overload(mfilename, q);

end

% $Id: round.m 373 2023-07-24 13:32:28Z sangwine $
