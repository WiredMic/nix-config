function Y = log(X)
% LOG Logarithm of the elements of a multivector array.
% (Clifford overloading of standard Matlab function.)

% Copyright © 2019, 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

check_signature(X);

S = get_signature(X);

if S(3) ~= 0
    error(['Cannot compute logarithms in algebras ', ...
           'with basis elements that square to zero.'])
end

% TODO The method used here is based on isomorphism with real/complex
% matrices and the matrix logarithm. We are forced to operate on one
% element of the input array at a time because of this. Maybe a better
% algorithm is possible?

% Convert the input array to a column vector of multivectors and then to an
% isomorphic block matrix of reals/complexes. We do it in this way and not
% by converting the multivectors one-by-one as the computation of the
% isomorphism requires switching of algebras which can be very
% time-consuming.

NX = numel(X);

M = iso(reshape(X, [NX, 1])); % A column of blocks, one per element of X.

N = size(M, 2); % This is the size of the blocks within M.

C = false(NX, 1); % This will note where any negative eigenvalues are found.

% Now compute the matrix logarithm of each of the blocks. There is a
% complication here: if the matrix P whose matrix logarithm is to be
% computed, has negative eigenvalues, then we need to adjust the formula.
% The negative eigenvalue issue and the solution used here is covered in:
%
% Paul Leopardi, 'Approximating functions in Clifford algebras: What to do
% with negative eigenvalues', Australian Mathematical Society Meeting,
% Adelaide, September 2009. [PDF presentation slides, slide 18.] Available:
% https://maths-people.anu.edu.au/~leopardi/  ...
%         AGACSE-2010-Leopardi-clifford-functions-long-talk.pdf

% TODO We use the iso function here and not isom, because the latter
% results in matrices which are not accurately isomorphic. This seems to be
% a problem with the algorithm in isom/miso not shared by the algorithm
% used in iso. There is something deep about this which needs careful
% study, because the matrices produced by isom are indeed isomorphic in the
% multiplicative sense. So why are they not isomorphic when used to compute
% logarithms?

for j = 1:NX % Index through the blocks, one per element of X.
    k = j * N - N + 1 : j * N; % Index vector for the rows of M containing
                               % block j.
    P = full(M(k, :)); % Eig and logm require a full, not sparse, input.
    E = eig(P); % This is of course, an expensive step to avoid problems
                % with negative eigenvalues, but for now there is no other
                % way!
    if any(real(E) < 0 & abs(imag(E)) <= eps)
        % The formula here is due to Paul Leopardi (see above), and fixes
        % the case where E has some negative eigenvalues.
        Q = logm(-1i .* P);
        C(j) = true;
    else
%         assert(~any(abs(real(E)) <= eps), ...
%             'Imaginary eigenvalues found, cannot deal with!');
        Q = logm(P);
    end
    M(k, :) = sparse(Q);
end

% Compute the inverse isomorphism to convert back from real/complex blocks
% to multivectors, add in the correction to elements which were fixed above
% to deal with negative eigenvalues, and reshape the result back to the
% size of the input array.

clifford_signature(0,0);

T = iso(M .* e0, S(1), S(2)); % Convert back to a column of multivectors.

% This is a class method, and hence we cannot directly use logical indexing
% on the multivector array T. See the file 'implementation notes.txt',
% item 'Indexing within class methods'.

r = substruct('()', {C});

T = subsasgn(T, r, subsref(T, r) + 1i .* pi ./ 2);
% T(C) = T(C) + 1i .* pi ./ 2;

Y = reshape(T, size(X));

end

% $Id: log.m 389 2024-02-08 20:55:47Z sangwine $
