function a = fix(q)
% FIX Round towards zero.
% (Clifford overloading of standard Matlab function.)

% Copied from the Quaternion Toolbox for MATLAB (QTFM).

% Copyright © 2006 Stephen J. Sangwine and Nicolas Le Bihan.

% Clifford modifications:
% Copyright © 2023 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1) 

a = overload(mfilename, q);

end

% $Id: fix.m 373 2023-07-24 13:32:28Z sangwine $
