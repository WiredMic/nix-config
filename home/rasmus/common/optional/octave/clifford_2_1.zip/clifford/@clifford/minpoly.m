function p = minpoly(m)
% MINPOLY Minimal polynomial of a Clifford multivector. 

% Copyright © 2023 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% Reference:
%
% Acus, A. and Dargys, A., The characteristic polynomial in calculation of
% exponential and elementary functions in Clifford algebras,
% Math. Meth. Appl. Sci. (2023), pp. 1–15, DOI 10.1002/mma.9524.
% See also arxiv:2205.11984.

% This function operates elementwise on m, so if m is an array of
% multivectors, it computes the minimal polynomial coefficients of each
% element of m, returned in p. The results should be read along the last
% dimension (the preceding dimensions match those of the input multivector
% array). In particular, this means that the outputs will be row vectors in
% the case where the input was a 1-by-1 multivector.

% Since the minimal polynomials of different elements of m may have
% different lengths, there may be trailing zero coefficients in the result,
% up to the length of the longest minimal polynomial found.

% NOTE that there is potentially another possible use for this function: to
% compute the minimal polynomial of a matrix of multivectors (cf MATLAB's
% MINPOLY function). One day, maybe.

narginchk(1, 1), nargoutchk(0, 1)

check_signature(m);

global clifford_descriptor %#ok<GVMIS>

% The value N is defined by Shirokov (see the reference in the POLY
% function). We need this because it defines the maximum possible length of
% the minimal polynomial (the same length as the characteristic polynomial
% computed by POLY). Shirokov's N is one less than the length of the
% characteristic polynomial (because the first coefficient is always 1).

N = 2^fix((cast(clifford_descriptor.n, 'double') + 1)/2);

M = numel(m); % We are going to iterate over the elements of m using linear
              % indexing, so we need to know how many there are.

% Initialise an array for the results. For each element of m, we need to
% return a vector of coefficients, so we add another dimension of length 0
% to the size of m. The coefficients of the polynomial will then appear
% along the last dimension. The polynomials won't all be of the same
% length, but they can't be longer than the characteristic polynomial,
% which has length N.

p = zeros([M, 1, N + 1]); % This array will be reshaped at the end to the
                          % dimensions of m, plus one extra dimension.

% TODO Consider whether we should precompute the N powers of each element
% (more accurate, but we may not need some of them), or compute them by
% successive products (no wasted computation, but less accurate). Tricky.
% Or we could compute each power independently, for accuracy, but then
% computation will be duplicated or worse.

L = 0; % This will record the length of the longest minimal polynomial.

for j = 1:M % ... each element of the input array m.

    mj = subsref(m, substruct('()', {j})); % mj = m(j)

    pj = mj.^(0:N); % Compute powers of m(j). We may not need them all.

    % Now iterate over powers of mj until the nullspace is non-trivial.

    V = []; % This will be a matrix, with coefficients of the powers of
            % m(j) in successive columns.
    for k = 1:N + 1 % For each power of m(j) stored in pj.
        V = [V, transpose(cell2mat(coefficients(expand_zeros( ... % p(j)
             subsref(pj, substruct('()', {k}))))))]; %#ok<AGROW>
        nullspace = null(V);
        if ~isempty(nullspace), break, end
    end

    assert(~isempty(nullspace)); % This can only happen if the loop falls
                                 % through without the break being
                                 % triggered.
    if ~iscolumn(nullspace)

        % Most of the time we get a column vector, but we now have two or
        % more columns and we need one for what follows. For the moment, we
        % choose the column which yields the smaller norm when we compute
        % V * x, where x is the column. This would cope with more than two
        % columns, but for now we raise an error on three or more, because
        % we don't know whether that will ever happen.

        % Notes: to find a case where more than one column is found, use
        % the following code, and put a breakpoint on the IF immediately
        % below. Obviously to catch a case of more than 2 columns, put a
        % breakpoint on the error statement below, or pause on error.
        %
        % for j=1:100, m = randm; p = minpoly(m); end
        %
        % Then
        % for x=1:100, y = x/100; z(x) = norm(V * sum([y, 1 - y] .* nullspace, 2)); end
        % plot(z)
        % will show a minimum. We need to find the minimum.

        if size(nullspace, 2) > 2
            error(["More than 2 columns in nullspace, found: ", ...
                   num2str(size(nullspace, 2))])
        end

        T = V * nullspace;

        N1 = norm(T(:, 1));
        N2 = norm(T(:, 2));

        if N1 < N2
            J = 1;
        else
            J = 2;
        end
        nullspace = nullspace(:, J);

    end

    % We have found a non-trivial null space for V. Hence we can produce
    % the minimal polynomial of m(j).

    LN = length(nullspace);

    L = max(L, LN);

    p(j, 1, 1:LN) = transpose(flip(nullspace)) ./ nullspace(end);
end

% Trim any zero coefficients off the end of the polynomials. We know the
% length of the longest minimal polynomial. Any elements along the last
% dimension beyond that length will be zero, so we delete them.

p = p(:, 1:L);

% Reshape the output to have the same size as the input plus one extra
% dimension of length L.

p = reshape(p, [size(m), L]);

p = squeeze(p); % Remove singleton dimensions so that we return the minimum
                % sized result compatible with the size of m.

% Suppress coefficients which are close to zero. The first coefficient of
% the polynomial is always unity, therefore we have an absolute comparison
% between the smallest coefficients and the largest. The threshold value is
% arbitrary, in the absence of any specific reason to choose another value.

p(abs(p) < (10 .* eps)) = 0;

if iscolumn(p)
    p = p.'; % Always return a row vector when the result is a vector.
end

end

% $Id: minpoly.m 389 2024-02-08 20:55:47Z sangwine $
