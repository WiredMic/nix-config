function R = inv(a)
% INV   Inverse of a multivector (matrix).
% (Clifford overloading of standard Matlab function.)
%
% For a single multivector, this function computes the inverse if it can be
% computed. The result will be an Inf if the multivector has zero modulus.
% For matrices it computes the matrix inverse using an analytical formula
% based on partitioning the matrix into sub-matrices. If this fails because
% of infinities, an isomorphism with real/complex block matrices is tried.

% Originally adapted from the corresponding function in the Quaternion
% Toolbox for MATLAB (QTFM), Copyright © 2005 Stephen J. Sangwine and
% Nicolas Le Bihan. See the file : Copyright.m for further details.

% Reference: Wikipedia article on 'Matrix Inversion', 12 July 2005.
%            Wikipedia article on 'Schur Complement', 13 July 2005.
%
% A similar formula is given in:
%
% R. A. Horn and C. R. Johnson, 'Matrix Analysis',
% Cambridge University Press, 1985, Section 0.7.3, page 18.
%
% and in:
%
% Granino A. Korn and Theresa M. Korn, 'Mathematical Handbook for
% Scientists and Engineers' Dover, 2000. ISBN 978-0-486-41147-7.
% Section 20.3-4 equation (20.3-19)

% TODO If the input matrix is singular, this is not properly detected, and
% the warning given by MATLAB for the real/complex case is not replicated
% here. Singular matrices may arise during the course of the computation,
% and warnings will be output, even though the code computes a result by a
% different method (isomorphisms with real/complex matrices). Consider
% using cond or rcond to check for singular matrices in the intermediate
% results?

[r, c] = size(a);

if r ~= c
    error('Matrix must be square.');
end

if r == 0
    % The input matrix is empty. MATLAB returns an empty matrix in this
    % case, so we do the same, and the simplest way to do this is to return
    % the input parameter. Note that the empty matrix must be 0-by-0 since
    % we checked above that the matrix is square.
    R = a;
elseif r == 1  % c must also be 1, since we have checked that r == c above.
    R = power(a, -1); % The power function implements the inverse of a
                      % 1-by-1 multivector. NB The inverse may not exist
                      % and the result may be an infinity or NaN.
elseif r == 2

    % We handle the 2 by 2 case separately since this can be computed
    % using clifford products, rather than clifford matrix products.

    A = subsref(a, substruct('()', {1,1})); % A = a(1,1);
    B = subsref(a, substruct('()', {1,2})); % B = a(1,2);
    C = subsref(a, substruct('()', {2,1})); % C = a(2,1);
    D = subsref(a, substruct('()', {2,2})); % D = a(2,2);

    IA = inv(A); % If A is zero, or a divisor of zero, this will cause an
                 % Inf or NaN. This does not necessarily mean that the
                 % matrix a is singular, so we try an isomorphism.

    if any(isinf(IA), 'all') || any(isnan(IA), 'all')
        R = misoinvisom(a);
        return
    end

    IAB = IA .* B; % These two subexpressions are needed more than
    CIA = C .* IA; % once each, and are computed once for efficiency.

    T  = inv(D - CIA .* B); % This expression must not be singular! If it
                            % is, we will get infinities or NaNs and as
                            % above we resort to an ismorphism with
                            % real/complex matrices.
    
    if any(isinf(T), 'all') || any(isnan(T), 'all')
        R = misoinvisom(a);
        return
    end

    TCIA = T .* CIA; % This is needed twice, so compute it once and reuse.

    R = [[IA + IAB .* TCIA, -IAB .* T];...
         [           -TCIA,         T]];
else

    % For matrices larger than 2 by 2, we partition the matrix into sub
    % blocks of half the height/width of the input matrix. If the input
    % matrix has an even number of rows (and therefore columns,  since it
    % is square),  then the sub-blocks will be exactly half the height
    % (width),  otherwise the left block will have one less element,
    % because we round towards zero. The layout of the sub-blocks is:
    %
    %                 [ A B ]
    %                 [ C D ]
    %
    % the same as in the 2 by 2 case above (except that here they are
    % matrices and not scalars).

    p = fix(r./2); % Calculate half the number of rows/columns rounded down.
    q = p + 1;     % Index of first element of right or bottom block.

    A = subsref(a, substruct('()', {1:p, 1:p})); % A = a(1:p, 1:p);
    B = subsref(a, substruct('()', {1:p, q:c})); % B = a(1:p, q:c);
    C = subsref(a, substruct('()', {q:r, 1:p})); % C = a(q:r, 1:p);
    D = subsref(a, substruct('()', {q:r, q:c})); % D = a(q:r, q:c);

    IA = inv(A);

    if any(isinf(IA), 'all') || any(isnan(IA), 'all')
        R = misoinvisom(a);
        return
    end

    IAB = IA * B; %#ok<*MINV> % These two subexpressions are needed more
    CIA = C * IA; % than once each, and are computed once for efficiency.

    T  = inv(D - CIA * B);

    if any(isinf(T), 'all') || any(isnan(T), 'all')
        R = misoinvisom(a);
        return
    end

    TCIA = T * CIA; % This is needed twice, so compute it once and reuse.

    R = [[IA + IAB * TCIA, -IAB * T];...
         [          -TCIA,        T]];
end

end

function Y = misoinvisom(X)
% Computes the inverse of the real/complex matrix X using the isom/miso
% isomorphism pair.
T = isom(X);
U = inv(T); % This is the MATLAB inv on the real/complex matrix T.
Y = miso(U);
end

% $Id: inv.m 330 2022-04-22 20:56:33Z sangwine $
