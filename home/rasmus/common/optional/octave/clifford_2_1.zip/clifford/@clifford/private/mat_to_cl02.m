function  m = mat_to_cl02(M)

% Copyright © 2017 Harry I. Elman (code contributed to the toolbox with
% edits by Steve Sangwine). This code is licensed under the same terms as
% the toolbox itself, for which see the file : Copyright.m for further
% details.

% Edited 2022 (second time) to use a 2-by-2 complex representation.
% See the comment in cl02_to_mat.m for the reasoning, and the method which
% this code has to invert/undo.

N = deinterleave(M, 2);

[m, n] = size(N);

% TODO This would be neater with logical indexing, cf mat_to_cl30.

UL = N(1:m/2,   1:n/2); % Split out the upper and lower, left and right
LL = N(m/2+1:m, 1:n/2); % quadrants of the matrix N.
UR = N(1:m/2,   n/2+1:n);
LR = N(m/2+1:m, n/2+1:n);

a = (UL + LR) ./2;
b = (UL - LR) ./2i;
c = (LL + UR) ./2i;
d = (LL - UR) ./2;

clifford_signature(0, 2);

m = clifford(a, b, c, d);

end

% $Id: mat_to_cl02.m 359 2022-10-26 16:56:47Z sangwine $