function P = conformal_point(varargin)
% CONFORMAL_POINT  Create a conformal point multivector from coordinates.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global conformal_descriptor %#ok<GVMIS> 

nargoutchk(0,1);

if isempty(conformal_descriptor)
    error('No conformal algebra has been initialised.')
end

% Check that the number of coordinates supplied for the point P matches the
% dimensionality of the current conformal algebra.

N = sum(conformal_descriptor.signature);
L = length(varargin);

if L ~= N
    error(['Number of coordinates supplied does not match ', ...
           'dimensionality of current conformal algebra. Given, ', ...
           num2str(L), ' coordinates. Require: ', num2str(N)])
end

% Check that all of the parameters are numeric.

for j = 1:L
    if isnumeric(varargin{j})
        continue
    else
        error('Parameters must be numeric')
    end
end

% Check that all of the parameters are of the same class, and size.

if N > 1
    C = class(varargin{1});
    S = size (varargin{1});

    for j = 2:L
        if strcmp(C, class(varargin{j}))
            continue
        else
            error(['All coordinates must have the same class, '...
                   'found first parameter has class ', C, ' and ', ...
                   'parameter ', num2str(j), ' has class ', ...
                   class(varargin{j})])
        end
    end
    for j = 2:L
        if all(S == size(varargin{j}))
            continue
        else
            error('All coordinate arrays must be of the same size.')
        end
    end
end

% This is the formula that we implement below.
%
% P = eo + v(1) .* e1 + v(2) * e2 + .... v(n) * en + (1/2) * <v,v> * ei
%
% where v is a MATLAB column vector of basis elements scaled by the values
% from varargin.

P = eo; % put(P, coefficients(eo));

% Construct a Clifford vector from the input parameters.

U = vector(clifford_basis); % A column vector containing e1, e2, ..., en.

U = cast(U, C);

V = clifford(zeros(C));

for j = 1:length(varargin)
    V = V + U(j + 1) .* varargin{j};
end

P = P + V;

P = P + scalar_product(V, V) .* ei ./ 2;

end

% $Id: conformal_point.m 362 2022-11-01 15:17:59Z sangwine $
