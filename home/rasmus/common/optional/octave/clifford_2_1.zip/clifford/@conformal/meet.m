function m = meet(a, b)
% MEET Compute the meet of two conformal multivectors representing
% geometric objects.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(2, 2), nargoutchk(0, 1)

unimplemented(mfilename);

end

% $Id: meet.m 353 2022-10-18 20:25:13Z sangwine $
