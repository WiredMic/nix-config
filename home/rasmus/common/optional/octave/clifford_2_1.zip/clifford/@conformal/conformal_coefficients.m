function [A, B, C, D] = conformal_coefficients(M)
% CONFORMAL_COEFFICIENRS Decompose a clifford multivector into the four
% clifford multivector coefficients of a conformal multivector.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% TODO A reference here to a suitable paper would be helpful.

narginchk(1, 1), nargoutchk(0, 4)

check_signature(M);

% The results from the contractions are conformal multivectors, so we use
% get_clifford to drop the conformal part, and thus return a clifford
% multivector in each case.

% TODO The code below works only for conformal multivectors with double
% components. This is because the eo, ei and E functions return double
% components by default. Solution, cast eo, ei and E to the same component
% type as M.

assert(strcmp(classm(M), 'double'), ...
  'Cannot yet handle conformal multivectors with non-double components')

A = get_clifford( right_contraction(wedge(M,  E), E));
B = get_clifford( right_contraction(wedge(M, eo), E));
C = get_clifford(-right_contraction(wedge(M, ei), E));
D = get_clifford( right_contraction(      M,      E));

end

% $Id: conformal_coefficients.m 353 2022-10-18 20:25:13Z sangwine $
