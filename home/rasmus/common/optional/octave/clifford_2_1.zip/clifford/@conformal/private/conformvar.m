function m = conformvar(f, l, r, varargin)
% Private function to apply a clifford operation f on l, r and varargin,
% where there is a clifford function f(l, r, varargin) or f(varargin). f
% must be a function handle to the clifford function. It is needed because
% the clifford function will initialise a result which is a clifford
% multivector, rather than using one of l or r. Common cases are where the
% clifford function has to sum over grades, starting with a nil
% multivector. The clifford function does not of course know about
% conformal multivectors, and therefore returns a clifford result, when
% what we need is a conformal. See also CONFORM which does the special case
% where varargin is not present, i.e. f is a binary operation.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(2, inf), nargoutchk(0, 1)

lc = isa(l, 'conformal');
rc = isa(r, 'conformal');

% Caution! We cannot do the same as above with testing for clifford,
% because every conformal multivector is also a clifford multivector.

if lc && rc
    m = l;
    m.multivector = coefficients(f(get_clifford(l), get_clifford(r)));
elseif lc
    assert(isa(r, 'clifford') || isnumeric(r), ...
        'Second parameter is neither numeric nor a multivector')
    m = l;
    m.multivector = coefficients(f(get_clifford(l), r));
elseif rc
    assert(isa(l, 'clifford') || isnumeric(l), ...
        'First parameter is neither numeric nor a multivector')
    m = r;
    m.multivector = coefficients(f(l, get_clifford(r)));
else
    % Neither l nor r is conformal. One at least of the varargin parameters
    % must be conformal, otherwise this function would not have been
    % called. We can only handle this if l and r are clifford or numeric,
    % in which case we can call the clifford f function and carry on.

    % TODO The check on clifford here should use strcmp on class, in order
    % to detect subclasses which cannot be handled.
    assert((isa(l, 'clifford') || isnumeric(l)) && ...
           (isa(r, 'clifford') || isnumeric(r)), ...
        'One or both of the first two parameters is not a multivector')
    m = f(l, r); % Call the Clifford f function.
end

% We now have in m the f function of l and r. But we are not finished if
% varargin is non-empty.

if ~isempty(varargin)
    m = f(m, varargin{1}, varargin{2:end});
end

end

% $Id: conformvar.m 352 2022-10-18 20:21:17Z sangwine $
