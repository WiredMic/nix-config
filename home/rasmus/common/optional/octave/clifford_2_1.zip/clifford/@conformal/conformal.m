% Clifford Algebra Toolbox for MATLAB

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% Conformal Geometric Algebra

% This class extends the Clifford Multivector class so that computations
% can be performed with conformal geometric algebras using a Clifford
% algebra to provide the underlying computation.

% This class is a subclass of clifford, with inherited properties, methods
% etc. However, it also has to be superior to clifford, so that, for
% example, a call to wedge(e1, p) where e1 is a clifford multivector, and p
% is a conformal multivector, calls the conformal wedge function and not
% the clifford wedge function. If we did not do this, wedge(p, e1) would
% work, but wedge(e1, p) would give an error in the clifford wedge
% function.

classdef (InferiorClasses = {?clifford}) conformal < clifford

    properties (Access = private, Hidden = true)
        % Since this class is a subclass of clifford, every conformal
        % multivector also includes a clifford multivector, which itself
        % contains a signature of the clifford algebra. Thus we can check
        % that the two signatures are consistent when a conformal
        % multivector is used, except in clifford functions, which don't
        % have access to the conformal fields.

        conformal_signature % The signature of the conformal algebra [p, q].
    end

    methods

        function c = get_clifford(m)
        % GET_CLIFFORD returns the Clifford multivector part of the
        % conformal multivector.

        c = clifford(m); % This will return only the clifford part, because
                         % it has been modified to omit the subclass parts.
        end

        function r = put_clifford(m, v)
            % An internal function to assign a value to the multivector
            % part of a conformal multivector. m must be a conformal
            % multivector in the current algebra and v must be a Clifford
            % multivector of the correct signature (not checked, this is an
            % internal function).
            % We do not check the parameters in order to reduce overhead,
            % since the purpose of this function is to make possible
            % efficient insertion of a value into a multivector. Note that
            % it is not necessary to use this function from within a class
            % method, since such methods can directly manipulate the fields
            % within a multivector.
            
            r = m; % Copy the input multivector.
            r.multivector = v;
        end
        
        function s = get_conformal_signature(m)
        % GET__CONFORMAL_SIGNATURE returns the signature of a conformal
        % multivector.
            s = m.conformal_signature;
        end

        function check_conformal_signature(m)
        % CHECK_CONFORMAL_SIGNATURE Checks that the signature of an object
        % m matches with the current signature and raises an error if they
        % do not match. This should be called from any class method that
        % has conformal multivectors as input parameters, and it should be
        % called on each such parameter to guard against attempts to
        % combine multivectors with differing signatures.
        
        global conformal_descriptor %#ok<*GVMIS> 
        
        if isempty(conformal_descriptor)
            error('No conformal algebra has been initialised.')
        end

        if any(m.conformal_signature ~= conformal_descriptor.signature)
            error(['Conformal multivector has a signature different to '...
                   'that of the current conformal algebra.'])
        end

        % Check that the Clifford signature of m is also correct.

        if any(m.signature ~= clifford_signature)
            error(['Conformal multivector has a Clifford signature ' ...
                   'different to that of the current Clifford algebra'])
        end

        end

        function object = conformal(a)
        % CONFORMAL constructor.
        
        global conformal_descriptor

        if isempty(conformal_descriptor)
            error(['The conformal algebra you wish to use must first be ' ...
                   'initialised by calling conformal_signature(p, q)'])
        end

        % Problem here. The Clifford constructor below returns a conformal.
        % Why? It's what we need but why does it work?

        object@clifford();
        assert(isa(object, 'conformal'))

        object.conformal_signature = conformal_descriptor.signature;
     
        switch nargin
            case 0
                return % We did all we needed just above.
            case 1
                if isnumeric(a)
                    % Construct a Clifford multivector from the numeric,
                    % and handle it recursively.
                    object = conformal(clifford(a));
                else
                    c = class(a);
                    if strcmp(c, 'conformal') %#ok<STISA> 
                        object = a; % The parameter is already conformal,
                                    % so just return it unmodified.
                    elseif strcmp(c, 'clifford') %#ok<STISA> 
                        object.multivector = coefficients(a);
                        object.signature   = get_signature(a);
                    else
                        error(['Cannot construct a conformal from: ', c])
                    end
                end
            otherwise
                error(['Can handle only 0 or 1 input, given: ', ...
                        num2str(nargin)])
        end

        end

        function n = numArgumentsFromSubscript(~,~,~)
            % Introduction of this function with Matlab R2015b
            % permitted numel to revert to its obvious function
            % of providing the number of elements in an array.
            n = 1;
        end

        function dump2(cmv) % TODO This should be named dump,
            % but that causes an infinite loop. To avoid we need to specify
            % the clifford dump function somehow.
            disp('Clifford multivector (superclass part of conformal multivector)')
            dump(cmv)
            disp('Conformal properties (subclass part of conformal multivector)')
            disp('Conformal signature: '); disp(cmv.conformal_signature);
        end

        % TODO We should also create the following methods:  empty

    end
end

% $Id: conformal.m 353 2022-10-18 20:25:13Z sangwine $
