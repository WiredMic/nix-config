function m = plus(l, r)
% PLUS  Addition of conformal/clifford multivectors.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% The clifford plus function is a critical function in the toolbox, very
% important for the speed of computation with Clifford multivectors.
% However, it always uses the left parameter to construct the result,
% adding elements of the right parameter to it. This means that in the
% absence of this conformal plus function, addition of a conformal to a
% clifford would give different results according to order. Rather than add
% code to the clifford plus function to handle this, which would slow it
% down when working on clifford multivectors, this function checks the two
% parameters and ensures that the left parameter is conformal. Addition of
% course is commutative, which is why we can get away with this trick.

narginchk(2, 2), nargoutchk(0, 1)

m = conform(str2func(mfilename), l, r);

end

% $Id: plus.m 353 2022-10-18 20:25:13Z sangwine $
