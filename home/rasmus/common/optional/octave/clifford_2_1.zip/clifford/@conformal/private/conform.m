function m = conform(f, l, r)
% Private function to apply a clifford binary operation f on l and r where
% there is a clifford function f(l, r). f must be a function handle to the
% clifford function. It is needed because the clifford function will
% initialise a result which is a clifford multivector, rather than using
% one of l or r. Common cases are where the clifford function has to sum
% over grades, starting with a nil multivector. The clifford function does
% not of course know about conformal multivectors, and therefore returns a
% clifford result, when what we need is a conformal.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

lc = isa(l, 'conformal');
rc = isa(r, 'conformal');

% Caution! We cannot do the same as above with testing for clifford,
% because every conformal multivector is also a clifford multivector.

if lc && rc
    m = l;
    m.multivector = coefficients(f(get_clifford(l), get_clifford(r)));
elseif lc
    % The r parameter could be a clifford, a numeric, or a subclass, or
    % something else. Only the first two are acceptable, since we can't
    % apply a clifford function to parameters of two different subclasses.
    % Note that to detect whether r is a clifford and not a subclass of
    % clifford, we have to use class and not isa. r cannot be conformal, as
    % we eliminated that case above.

    if isnumeric(r) || strcmp(class(r), 'clifford') %#ok<STISA,LTARG> 
        m = l;
        m.multivector = coefficients(f(get_clifford(l), r));
    else
        error(['Cannot handle right parameter of class: ', class(r)])
    end
elseif rc
    % See comment above in previous elseif.

    if isnumeric(l) || strcmp(class(l), 'clifford') %#ok<STISA,LTARG> 
        m = r;
        m.multivector = coefficients(f(l, get_clifford(r)));
    else
        error(['Cannot handle left parameter of class: ', class(l)])
    end
else
    error('Neither parameter is a conformal; should not happen!')
end

end

% $Id: conform.m 352 2022-10-18 20:21:17Z sangwine $