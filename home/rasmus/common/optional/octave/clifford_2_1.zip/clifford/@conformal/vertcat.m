function m = vertcat(varargin)
% VERTCAT  Vertical concatenation of conformal multivectors.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, inf), nargoutchk(0, 1)

lv = length(varargin);

if lv == 1
    m = varargin{1}; % One parameter, just return it unchanged.
else
    m = conformvar(str2func(mfilename), ...
                   varargin{1}, varargin{2}, varargin{3:end});
end

end

% $Id: vertcat.m 353 2022-10-18 20:25:13Z sangwine $
