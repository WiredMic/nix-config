function m = dual(a)
% DUAL Compute the dual of a conformal multivector.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

m = a;

m.multivector = coefficients(dual(get_clifford(a)));

end

% $Id: dual.m 353 2022-10-18 20:25:13Z sangwine $
