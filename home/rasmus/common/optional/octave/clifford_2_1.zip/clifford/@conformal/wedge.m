function m = wedge(l, r, varargin)
% WEDGE Compute the wedge product of two or more multivectors.

% TODO It makes sense perhaps to consider allowing a single parameter which
% must be an array of multivectors, and the function wedges them all
% together. But be careful about dimensions - would we wedge pointwise? In
% CGA this is a common operation, e.g. to wedge together three points to
% make a circle.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(2, inf), nargoutchk(0, 1)

lc = isa(l, 'conformal');
rc = isa(r, 'conformal');

% TODO There should be a check here or in the if elsif below, that the two
% parameters have consistent signatures. In particular if one is Clifford
% and the other is conformal, we need to be sure that the Clifford algebra
% is correct for the conformal algebra. This is quite a big TODO.

% Caution! We cannot do the same as above with testing for clifford,
% because every conformal multivector is also a clifford multivector.

if lc && rc
    m = l;
    m.multivector = coefficients(wedge(get_clifford(l), get_clifford(r)));
elseif lc
    assert(isa(r, 'clifford'), 'Second parameter is not a multivector')
    m = l;
    m.multivector = coefficients(wedge(get_clifford(l), r));
elseif rc
    assert(isa(l, 'clifford'), 'First parameter is not a multivector')
    m = r;
    m.multivector = coefficients(wedge(l, get_clifford(r)));
else
    % Neither l nor r is conformal. One at least of the varargin parameters
    % must be conformal, otherwise this function would not have been
    % called. We can only handle this if l and r are clifford, in which
    % case we can call the clifford wedge function and carry on.
    assert(isa(l, 'clifford') && isa(r, 'clifford'), ...
        'One or both of the first two parameters is not a multivector')
    m = wedge(l, r); % Call the Clifford wedge function.
end

% We now have in m the wedge product of l and r. But we are not finished if
% varargin is non-empty.

if ~isempty(varargin)
    m = wedge(m, varargin{1}, varargin{2:end});
end

end

% $Id: wedge.m 353 2022-10-18 20:25:13Z sangwine $
