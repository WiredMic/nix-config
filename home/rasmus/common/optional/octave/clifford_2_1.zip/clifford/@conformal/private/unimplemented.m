function unimplemented(name)
% Output error message about unimplemented function.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

disp(['Unimplemented conformal function: ', name]);
error('Call to unimplemented function.');

% $Id: unimplemented.m 352 2022-10-18 20:21:17Z sangwine $
