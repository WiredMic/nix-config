function r = classm(m)
% Private function to return the class of the elements of a multivector.

% Copyright © 2015 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

r = class(m.multivector{1});

% TODO It should not be necessary to duplicate this function for conformal,
% but for now this is a quick fix.

end

% $Id: classm.m 352 2022-10-18 20:21:17Z sangwine $
