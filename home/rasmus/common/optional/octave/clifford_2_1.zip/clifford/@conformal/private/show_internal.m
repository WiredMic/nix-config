function show_internal(name, value)
% Displays the components of a conformal multivector (array). This code is
% called from show.m, which must pass the name of the variable as a string.
% (It may be empty if the value is anonymous, as results for example, from
% the call 'show(e1)'.)

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

global conformal_descriptor %#ok<GVMIS> 

if isempty(conformal_descriptor)
    error('No conformal algebra has been initialised.')
end

check_conformal_signature(value);

if isempty(value)
    
    if ~isempty(name)
        disp(' ');
        disp([name, ' =']);
    end

    % There are no numeric values to be output, so we simply output a
    % description of the empty value, depending on its size, which may be
    % 0-by-0, or 0-by-N, and it may be a matrix (2-dimensional) or an array
    % (more than two-dimensional). We can output something informative in
    % all these cases and not just '[]'.
    
    S = blanks(5);
    d = size(value);
    if sum(d) == 0
        S = [S '[] conformal multivector'];
    else
        S = [S 'Empty multivector'];
        l = length(d);
        if l == 2
            S = [S ' matrix: '];
        else
            S = [S ' array: '];
        end
        for k = 1:l
            S = [S, num2str(d(k))]; %#ok<*AGROW>
            if k == l
                break % If we have just added the last dimension, no need
                      % for another multiplication symbol.
            end
            S = [S, '-by-'];
        end
    end
    disp(S)
else
    % The multivector is not empty, therefore we can output numeric data.
    % We do this by outputting the components one by one. There is a
    % special case if the multivector is scalar, since we can output this
    % in one step, using disp.
        
    disp(' ');
    if isscalar(value)
        if ~isempty(name)
            disp([name, ' ='])
            disp(' ')
        end
        disp(value);
        disp(' ');
    else
        S = conformal_descriptor.strings;
        if isempty(name)
            name = 'unnamed';
        end
        disp([name, ' = a + b .* ', S{2}, ' + c .* ', S{1}, ' + d .* ', S{3}, ', where:']);

        % Output the components of the conformal multivector one by one.
        % Each is a clifford multivector array, so the show function called
        % here is the clifford function.

        [a, b, c, d] = conformal_coefficients(value);

        show(a)
        show(b)
        show(c)
        show(d)
    end
end

% $Id: show_internal.m 352 2022-10-18 20:21:17Z sangwine $
