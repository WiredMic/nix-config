function show(m)
% SHOW   Displays the components of a conformal multivector (array).

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

show_internal(inputname(1), m);

% $Id: show.m 353 2022-10-18 20:25:13Z sangwine $
