function m = dip(l, r)
% DIP  Dorst inner product.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

% This is one of several functions that cannot be computed by direct call
% to the clifford function of the same name, if either or both of l and r
% is a conformal multivector. For the reasons see the private function
% conform which is called below.

narginchk(2, 2), nargoutchk(0, 1)

m = conform(str2func(mfilename), l, r);

end

% $Id: dip.m 353 2022-10-18 20:25:13Z sangwine $
