function disp(m)
% DISP Display a conformal multivector.

% TODO This function is very basic compared to the equivalent Clifford
% function which outputs a lot more descriptive information about the
% components (e.g. complex, class if not double, row vector, etc).

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 0)

global conformal_descriptor %#ok<GVMIS> 

% Handle the case where the input parameter does not have the current
% conformal signature. We could output a value with more work here, but it
% is sufficient to output a sensible message and return. What's important
% is not to raise an error.

if any(m.conformal_signature ~= conformal_descriptor.signature)
    disp('Unable to show value')
    disp(['Multivector has conformal signature ' signature_string(m)])
    disp(['Current conformal algebra signature ' signature_string(conformal_descriptor)])
    return
end

SS = ['(', num2str(conformal_descriptor.signature(1)), ',', ...
           num2str(conformal_descriptor.signature(2)), ')'];
S = ' ';
if isempty(m)
    disp([S '    [] conformal ', SS, ' multivector']);
elseif isscalar(m)
    
    [a, b, c, d] = conformal_coefficients(m);

    % TODO The char function here is the clifford char, and the strings are
    % padded with leading and trailing spaces which are chosen to suit the
    % output of clifford multivectors. For the purposes here, there are too
    % many spaces added. To reduce this we could implement a local char
    % function, perhaps local to this function.
    
    disp([S '    ' char(a)]);
    disp([S ' + (' char(b) ') * ', conformal_descriptor.strings{2}]);
    disp([S ' + (' char(c) ') * ', conformal_descriptor.strings{1}]);
    disp([S ' + (' char(d) ') * ', conformal_descriptor.strings{3}]);
else
    % Non-scalar case. Build up the string piece by piece, then output it
    % when complete.
    
    d = size(m);
    l = length(d);
    for k = 1:l
        S = [S, num2str(d(k))];
        if k == l
            break % If we have just added the last dimension, no need for
                  % another multiplication symbol.
        end
        S = [S, '×'];
    end
    disp([S, ' conformal ', SS, ' multivector'])
end

    function s = signature_string(a)
        % The parameter may be a multivector or a conformal descriptor,
        % since either has a signature field.
        s = ['(' num2str(a.signature(1)) ',' num2str(a.signature(2)), ')'];
        assert(length(s) == 2) % This code was copied from the clifford
                               % case where the length would be 3. Check it
                               % just in case.
    end

end

% $Id: disp.m 361 2022-10-26 21:20:26Z sangwine $
