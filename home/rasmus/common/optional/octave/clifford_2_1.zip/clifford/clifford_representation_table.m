function T = clifford_representation_table
% CLIFFORD_REPRESENTATION_TABLE This function creates a printable character
% array containing a representation of the matrix representation created by
% CLIFFORD_REPRESENTATION. The table applies for the current algebra
% initialised with CLIFFORD_SIGNATURE.

% Copyright © 2022 Stephen J. Sangwine and Eckhard Hitzer.

global clifford_descriptor %#ok<GVMIS> 

if isempty(clifford_descriptor)
    error('No algebra currently initialised, cannot proceed.')
end

% Compute the set of literals in lexical order.

m = cast(clifford_descriptor.m, 'double'); % Cast these to double to permit
n = cast(clifford_descriptor.n, 'double'); % multiplication below @ line 23

C = clifford_representation; % These are the n representations of the
                             % vectors e_1 .. e_n.

[~, ~, E] = clifford_lexical_index_mapping(n);

w = 3 + n; % The max width of a basis literal such as
           % e123, including sign and a trailing space.

for j=1:length(E)
    E{j}(1) = 'c'; % Change the literals from e1 to c1 (c for coefficient).
end

% Pre-allocate the result array, and populate it with spaces.

T = repmat(blanks(m .* w), [m, 1]);

T(:, 2:w:end) = '0'; % Pre-fill array with zeros in each row and column.
                     % These will be overwritten if a -1 or 1 occurs in the
                     % relevant basis matrix.

for j=1:m % For each basis element of the algebra.
    M = basis_element(E{j}(2:end));
    for c=1:m % For each column of M.
        x = (c - 1) * w + 1; % Index to the column of T corresponding to c.
        for r=1:m % For each row of m.
            switch M(r, c)
                case -1
                    T(r, x:x+w-1) = pad(['-', E{j}], w);
                case  0
                    continue % Do nothing.
                case +1
                    T(r, x:x+w-1) = pad([' ', E{j}], w);
                otherwise
                    error('Value in matrix representation not in {-1, 0, +1}')
            end
        end
    end
end

    function B = basis_element(index_string)
        % Construct the basis element of the algebra corresponding to the
        % string of index characters passed in.

        Index_Characters = '123456789abcdefg';

        IC = Index_Characters(1:n);

        assert(length(IC) == length(C));

        if length(index_string) == 1
            if index_string == '0'
                B = speye(m); % e0 is represented by the identity matrix.
            else
                % Representations of e_1 .. e_2 are stored in C, select
                % one according to the index character.
                B = C{index_string == IC};
            end
        else
            % The index string contains 2 or more characters, therefore we
            % have to construct the matrix representation from elements of
            % C selected by the characters in the index string converted to
            % numerical indices.

            B = speye(m); % Start with an identity matrix.

            for k = 1:length(index_string)
                % Logical indexing here is used to convert the character
                % '1' to 'g' into a numerical index into the cell array C,
                % thus selecting the element of E that corresponds to the
                % k-th character of the index string.
                B = B * C{index_string(k) == IC};
            end
        end
    end
end

% $Id: clifford_representation_table.m 317 2022-03-06 20:07:09Z sangwine $
